source("globalArgs.R")
library(data.table)
library(gtools)

data=fread("/home/ulfha881/Desktop/COVID-19/MyData/Hashtable_UK.txt")
data[,patient_id:=as.character(patient_id)]
setkey(data,'patient_id')

selection=c('patient_id','fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
            'chest_pain','hoarse_voice','loss_of_smell','headache','chills_or_shivers','eye_soreness',
            'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
            'typical_hayfever','sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath',
            'health_status','updated_at','other_symptoms','altered_smell','unusual_joint_pains')
assess_data<-fread(filereader,sep=",",select=selection)
setkey(assess_data,'patient_id')
assess_data=assess_data[data,nomatch=0]
assess_data[,patient_id:=NULL]
assess_data[other_symptoms!="",other_symptoms:="other"]
setnames(assess_data,'new_id','patient_id')
assess_data[,patient_id:=as.character(patient_id)]
filer2=substr(filereader,42,200)
fwrite(assess_data,paste0("/home/ulfha881/Desktop/COVID-19/OriginalData/ToyDataCurrent_UK/",filer2))