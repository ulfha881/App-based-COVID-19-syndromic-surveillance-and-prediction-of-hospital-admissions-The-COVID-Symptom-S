foldrs=c('Current_SWE','ModelBuilding')

source("globalArgs.R")
library(data.table)
library(gtools)
data=fread("/home/ulfha881/Desktop/COVID-19/MyData/Hashtable_SWE.txt")
setkey(data,'patient_id')

for (i in foldrs){
  selection=c('patient_id','fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
              'chest_pain','hoarse_voice','loss_of_smell','headache','chills_or_shivers','eye_soreness',
              'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
              'typical_hayfever','sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath',
              'health_status','updated_at','other_symptoms','altered_smell','unusual_joint_pains')
  print(i)
  assess_data<-fread(paste0("/proj/sens2020559/COVID-19/OriginalData/",i,"/assessments.txt"),sep=",",select=selection)
  setkey(assess_data,'patient_id')
  assess_data=assess_data[data,nomatch=0]
  assess_data[,patient_id:=NULL]
  assess_data[other_symptoms!="",other_symptoms:="other"]
  setnames(assess_data,'new_id','patient_id')
  assess_data[,patient_id:=as.character(patient_id)]
  fwrite(assess_data,paste0("/home/ulfha881/Desktop/COVID-19/OriginalData/ToyData",i,"/assessments.txt"))
  
  patient_data<-fread(paste0("/proj/sens2020559/COVID-19/OriginalData/",i,"/patients.txt"),sep=",")
  setnames(patient_data,'id','patient_id')
  setkey(patient_data,'patient_id')
  patient_data=patient_data[data,nomatch=0]
  patient_data[,patient_id:=NULL]
  patient_data[,race_other:=NULL]
  patient_data[,vs_other:=NULL]
  patient_data[,diabetes_oral_other_medication:=""]
  patient_data[,diabetes_type_other:=""]
  patient_data[,last_asked_level_of_isolation:=NULL]
  
  outward=patient_data[,se_postcode]
  outward=permute(outward)
  patient_data[,se_postcode:=outward]
  
  setnames(patient_data,'new_id','patient_id')
  print(head(patient_data))
  patient_data=data.table(patient_data)
  patient_data[,patient_id:=as.character(patient_id)]
  patient_data=patient_data[!duplicated(patient_id),]
  fwrite(patient_data,paste0("/home/ulfha881/Desktop/COVID-19/OriginalData/ToyData",i,"/patients.txt"))
  
  covid_data=fread(paste0("/home/ulfha881/Desktop/COVID-19/OriginalData/",i,"/covid_test.txt"))
  setkey(covid_data,'patient_id')
  covid_data[,location_other:=NULL]
  
  #"anonymizes" the free text, yet makes sure that the same persons will match for antibody and PCR, respectively.
  covid_data[grep("blod",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("blood",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("antikr",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("stick",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("kapill",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("stack i",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("immun",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("IgG",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("Imuni",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("Finger",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("IgM",mechanism,ignore.case=TRUE),mechanism:="blod"] 
  covid_data[grep("Venprov",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("armv",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("anitkropp",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("kapill",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("Kaplär",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("Serologiskt",mechanism,ignore.case=TRUE),mechanism:="blod"]
  covid_data[grep("venös",mechanism,ignore.case=TRUE),mechanism:="blod"]
  
  covid_data[grep("swab",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("pinne",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("svalg",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("svalj",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("tops",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("spit_tube",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("spott",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("Naso",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("hals",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("saliv",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("PCR",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("sputum",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("Nose",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("näs",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("Nadophar",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("throat",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("Nasalt/Oralt",mechanism,ignore.case=TRUE),mechanism:="swab"]
  covid_data[grep("region Skånes testkit",mechanism,ignore.case=TRUE),mechanism:="swab"]
  
  covid_data=covid_data[data,nomatch=0]
  covid_data[,patient_id:=NULL]
  setnames(covid_data,'new_id','patient_id')
  covid_data[,patient_id:=as.character(patient_id)]
  fwrite(covid_data,paste0("/home/ulfha881/Desktop/COVID-19/OriginalData/ToyData",i,"/covid_test.txt"))
}