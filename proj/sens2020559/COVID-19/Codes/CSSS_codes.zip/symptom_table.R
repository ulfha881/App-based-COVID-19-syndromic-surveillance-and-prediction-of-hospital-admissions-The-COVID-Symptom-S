#this file takes the "Assessment_for_model"-file from "2_preprocessing_abbrev",
#containing symptoms per individual and day. It sums the number of symptomatics per day, 
#and also calculates the number of individuals making an update (or several) per day,
#exporting a file containing this aggregate information.
library(data.table)

data=fread("/proj/sens2020559/COVID-19/MyData/Assessment_for_model")

symptoms=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
           'chest_pain','hoarse_voice','loss_of_smell','headache','chills_or_shivers','eye_soreness',
           'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
           'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath')

data[,(symptoms):=lapply(.SD,as.numeric),.SDcols=symptoms] #() är ett alternativt sätt att skriva with=FALSE vid assignment
data[,(symptoms):=lapply(.SD,sum),.SDcols=symptoms,by=updated_at] #() är ett alternativt sätt att skriva with=FALSE vid assignment
data[,N:=.N,by=updated_at] #() är ett alternativt sätt att skriva with=FALSE vid assignment

tokeep=union(symptoms,'updated_at')
tokeep=union(tokeep,'N')
data=data[,..tokeep]
data=unique(data)
fwrite(data,"/proj/sens2020559/COVID-19/MyData/Assessment_for_symptom_table.txt")
warnings()