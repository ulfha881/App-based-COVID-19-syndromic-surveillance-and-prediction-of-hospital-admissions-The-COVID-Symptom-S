#BUILDS THE REGRESSION MODEL, CALIBRATES IT USING THE INTERCEPT FROM 8_intercept_calibration.R,
#AND THEN USING IT FOR PREDICTIONS ON COUNTY AND POSTAL CODE LEVEL. 
#ALSO USES DIRECT STANDARDIZATION FOR REWEIGHTING COEFFICIENTS BY STRATA.
library("data.table")
source("/home/ulfha881/Desktop/COVID-19/Codes/globalArgs.R")
set.seed(10000) #seed for LASSO lamda cross-validation to remain consistent

#choose type before running the code (county or postcode)
sens=0.7

#these folders need to be created manually
if (type=="county") folder="CountyPred"
if (type=="region") folder="Region"

extension_save=substr(filereader,48,52) #to use for sorting out which weeks predictions belong to

#call function for model building.
source("/home/ulfha881/Desktop/COVID-19/Codes/model_building.R")
library(data.table)

#here we store the intercept generated in "8_intercept_calibration".
new_intercept=as.numeric(fread(paste0("/proj/sens2020559/COVID-19/MyData/Calibrations",modeltype,sensitivity,SCAD,".txt")))

model_building()
model2$a0=new_intercept #re-calibration of intercept
if (SCAD=="SCAD") model2$beta[1]=model2$a0

saveRDS(model2,paste0("/proj/sens2020559/COVID-19/MyData/Model",SCAD,sensitivity,modeltype,".rds"))
model2<-readRDS(paste0("/proj/sens2020559/COVID-19/MyData/Model",SCAD,sensitivity,modeltype,".rds"))

predict_data=fread("/proj/sens2020559/COVID-19/MyData/FullPredictionData.txt")

#county/2-digit
predict_data[,(type):=lapply(.SD,as.factor),.SDcols=type]
names<-levels(predict_data[,get(type)])

#temporary files for each category
for (i in names){
  tmp=predict_data[get(type)==(i),]
  fwrite(tmp,paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Pred",i,".txt"))
}

rm(tmp)
rm(predict_data)
rm(model_data)

#loop over each category, 
for (i in names){
  predict_data=fread(paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Pred",i,".txt"))
  predict_data[,SymptomDate:=as_date(updated_at)]
  pid=(predict_data[,patient_id])
  pid=unique(pid)

#  for (vary in variables){
#    predict_data[get(vary)<0,(vary):=0]
 # }
  
  if (modeltype=="TUP"){
	m=ns(predict_data[,SymptomDate],knots=c(knots[1],knots[2],knots[3],knots[4],knots[5]),Boundary.knots=c(bknots[1],bknots[2]))
 	predict_data[,time_spl1:=..m[,1]]
 	predict_data[,time_spl2:=..m[,2]]
  	predict_data[,time_spl3:=..m[,3]]
  	predict_data[,time_spl4:=..m[,4]]
  	predict_data[,time_spl5:=..m[,5]]
  	predict_data[,time_spl6:=..m[,6]]
  }
  flowchart=cbind(paste0("Number of rows in",type,i),length(predict_data[,patient_id]))
  flowchart=rbind(flowchart,cbind(paste0("Number of patients in",type,i),length(pid)))
  
  pid=unique(predict_data[,patient_id])
  if (ukdata=="ukdata") setnames(predict_data,"region","county") #for the rest of the code to match smoothly
  columns=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
            'chest_pain','hoarse_voice','loss_of_smell','headache','eye_soreness',
            'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
            'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath',
            'gender','age','updated_at','patient_id','group','county')
  if (modeltype=="TUP") columns=c(columns,timevar)
  
  setkey(predict_data,'patient_id')
  predict_data=predict_data[,..columns]
  predict_data=na.omit(predict_data)

  #for (vary in variables){
    #predict_data[get(vary)<0,(vary):=0]
    #}
  
  #create interaction terms
  for (var in variables){
    predict_data[,paste0("loss_",var):=loss_of_smell*get(var)]
  }
  predict_data=na.omit(predict_data)
  
  #LASSO must only include variables used in the model
  updated_at=predict_data[,updated_at]
  patient_id=predict_data[,patient_id]
  group=predict_data[,group]
  county=predict_data[,county]
  predict_data[,updated_at:=NULL]
  predict_data[,patient_id:=NULL]
  predict_data[,group:=NULL]
  predict_data[,county:=NULL]
  #LASSO predictions
  predict_data=as.matrix(predict_data)
  pred_tmp=predict(model2,predict_data,type="response")
  predict_data=data.table(predict_data)
  
  #Reintroduces variables not used in LASSO
  predict_data[,updated_at:=..updated_at]
  predict_data[,group:=..group]
  predict_data[,pred:=..pred_tmp]
  patient_id=predict_data[,patient_id:=..patient_id]
  patient_id=predict_data[,county:=county]
  #Like in code 8 (and 10), here is where we define "symptomatic".
  predict_data[,symptomatic:=0]
  symptom_list=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
                 'chest_pain','hoarse_voice','headache','eye_soreness',
                 'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
                 'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath','loss_of_smell') 
  for (value in symptom_list){
    predict_data[get(value)!=0 & is.na(get(value))==FALSE,symptomatic:=1] #!=0 eftersom ålder och ev. tid ej 0/1.  
  }
  predict_data[symptomatic==0,pred:=0]
  
  predict_data=predict_data[,.(patient_id,updated_at,pred,group,county)]
  predict_data=unique(predict_data)
  #data generated in "expand.grid.R".
  postal_data=fread(paste0("/proj/sens2020559/COVID-19/MyData/Combinations/",folder,"/",i,".txt"))
  postal_data[,updated_at:=ymd(updated_at)]
  postal_data[,patient_id:=as.character(patient_id)]
  predict_data[,updated_at:=ymd(updated_at)]
  predict_data[,patient_id:=as.character(patient_id)]
  
  flowchart=cbind(paste0("No of individuals, prediction data",type,i),length(unique(predict_data[,patient_id])))
  flowchart=rbind(flowchart,cbind(paste0("No of rows, prediction data",type,i),length(predict_data[,patient_id])))
  predict_data=merge(predict_data,postal_data,all=TRUE,by=c('patient_id','updated_at'))
  flowchart=rbind(flowchart,paste0("No of individuals, prediction data after merge",type,i),length(unique(predict_data[,patient_id])))
  flowchart=rbind(flowchart,cbind(paste0("No of rows, prediction data after merge",type,i),length(predict_data[,patient_id])))
  
  #LOCF is carried out, after getting the data in the right order
  predict_data=predict_data[order(patient_id,updated_at),]
  predict_data[,pred:=na.locf(pred,na.rm=FALSE),by=patient_id]
  predict_data[,group:=as.integer(max(group,na.rm=TRUE)),by=patient_id]
  #ensures no -Inf for group (after max(...na.rm=TRUE)) and no NA:s for pred in data. Just a precaution.
  predict_data=predict_data[group==1 | group==2 | group==3 | group==4,]
  predict_data=predict_data[!is.na(pred),]
  
  if (ukdata!="ukdata") predict_data=predict_data[updated_at>ymd("20200509"),]
  predict_data[,category:=(i)] #for having the same name as in the "popcounty" file.
  print("ESSENTIAL TO TEST, COUNTY:")
  print(table(predict_data[,county]))
  print("ESSENTIAL TO TEST, CATEGORY:")
  print(table(predict_data[,category]))
  names2=c('pred','updated_at','patient_id','group','category')
  predict_data=predict_data[,..names2]
  predict_data[,group:=as.factor(group)]
  predict_data[,updated_at:=as.factor(updated_at)]
  
  flowchart=rbind(flowchart,paste0("No of individuals, prediction data after LOCF",type,i),length(unique(predict_data[,patient_id])))
  flowchart=rbind(flowchart,cbind(paste0("No of individuals, prediction data after LOCF",type,i),length(predict_data[,patient_id])))
  
  #If there are at least 200 individuals in a county/postal area, we run the reweighting, create the graphs etc.
  #This first part generates the number of individuals and summed predicted probabilities for each day.
  pid=unique(predict_data[,patient_id])
  length=length(pid)
  if (length>199){
    reweighing_data=matrix(nrow=0,ncol=5)
    for (m in levels(predict_data[,group])){
    data3=predict_data[group==(m),]
      for (j in levels(predict_data[,updated_at])){
       tmp=data.table(data3[updated_at==(j),])
        tmp[,pred:=sum(pred)]
        pid=unique(tmp[,patient_id])     
        tmp[,N:=length(pid)]
        tmp[,patient_id:=NULL]
        tmp=as.matrix(unique(tmp))
        reweighing_data=rbind(reweighing_data,tmp)
      }
    }
  }

  #...uses "ageadjust.direct" to extract adjusted rates with confidence interval.
  #creates a matrix with these values + the number of participants in total and in each strata (all "cbinds")
  if (length>199){
    pop=fread(paste0("/proj/sens2020559/COVID-19/MyData/pop",type,".txt"))
    pop=pop[category==(i),]
    reweighing_data=data.table(reweighing_data)
    reweighing_data[,updated_at:=as.factor(updated_at)]
    reweighing_data[,pred:=as.numeric(pred)]
    reweighing_data[,N:=as.numeric(N)]
    pop[,population:=as.numeric(population)]
    pop[,group:=as.factor(group)] #for matching with reweighing_data
    adjusted_prev=matrix(nrow=0,ncol=10)
    
    #generates reweighted prevalences each day, and stores them in the object "adjusted_prev". Here we also store the number of
    #participants in each group (N1-N4). This object is used for both output and plotting.
    for (n in levels(reweighing_data[,updated_at])){
      temp=reweighing_data[updated_at==(n),]
      temp=temp[order(group),]
      temp=merge(temp,pop,by=c("group","category"))
      N1=unique(temp[group==1,N])
      N2=unique(temp[group==2,N])
      N3=unique(temp[group==3,N])
      N4=unique(temp[group==4,N])
        temp[,pred:=pred/sens] #adjustment for sensitivity
        tmp=ageadjust.direct(count=temp[,pred],pop=temp[,N],stdpop=temp[,population])
        temp=temp[,N:=sum(N)]
        N=unique(temp[,N])
        
        if (length(N)==0) N=0
        if (length(N1)==0) N1=0
        if (length(N2)==0) N2=0
        if (length(N3)==0) N3=0
        if (length(N4)==0) N4=0
      
        tmp=t(tmp)
        tmp=cbind(tmp,n)
        tmp=cbind(tmp,N)
        tmp=cbind(tmp,N1)
        tmp=cbind(tmp,N2)
        tmp=cbind(tmp,N3)
        tmp=cbind(tmp,N4)
        adjusted_prev=rbind(adjusted_prev,tmp)
    }
    #generates a graph for each county/postal code. 
    #Rates and CI:s are put to NA for days with less than 5 participants in the smallest strata
    adjusted_prev=data.table(adjusted_prev)
    adjusted_prev=adjusted_prev[,n:=ymd(n)]
    adjusted_prev[,n:=as_date(n)]
    variab=c('crude.rate','adj.rate','uci','lci','N','N1','N2','N3','N4')
    adjusted_prev=adjusted_prev[,(variab):=lapply(.SD,as.numeric,na.rm=TRUE),.SDcols=variab]
    
    adjusted_prev[(N1<5 | N2<5 | N3<5 | N4<5),adj.rate:=NA]
    adjusted_prev[(N1<5 | N2<5 | N3<5 | N4<5),uci:=NA]
    adjusted_prev[(N1<5 | N2<5 | N3<5 | N4<5),lci:=NA]
    
    adjusted_prev[,adj.rate:=as.numeric(adj.rate)]

    ggplot(data=adjusted_prev)+geom_ribbon(aes(ymin=lci,ymax=uci,x=n),fill="gray",color="gray")+
    geom_line(aes(y=adj.rate,x=n))+geom_point(aes(y=adj.rate,x=n))+scale_x_date()+xlab("Date")+ylab("Predicted prevalence")
    ggsave(paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Strata/NoBoot/Adj_",i,"_.png"),device="png",dpi=300)
    ggplot(data=adjusted_prev)+geom_line(aes(y=adj.rate,x=n))+geom_point(aes(y=adj.rate,x=n))+scale_x_date()+xlab("Date")+ylab("Predicted prevalence")
    ggsave(paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Strata/NoBoot/AdjNoCI_",modeltype,i,SCAD,sensitivity,".txt"),device="tiff",dpi=300)
    
    plot=ggplot(data=adjusted_prev,aes(x=n,y=adj.rate,group=1))
    plot+geom_ribbon(aes(ymin=lci,ymax=uci),fill="gray80")+geom_point(color="gray60")+
    scale_x_date()+geom_smooth(se=F,color="black",span=0.3)+
    aes(x=n,y=adj.rate,group=1)+xlab("Date")+scale_y_continuous(labels=scales::percent)+
    ylab("Predicted prevalence")
    ggsave(paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Strata/NoBoot/NewAdj_",i,modeltype,SCAD,sensitivity,".png"),device="png",dpi=300)
    #the "_"  in the fwrite is important to distinguish TUP and main in the "Correlations with hospitalization.do"-code
    if (ukdata!="ukdata") fwrite(adjusted_prev,(paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Strata/NoBoot/Pred",i,"_",modeltype,SCAD,sensitivity,".txt")))
    if (ukdata=="ukdata") fwrite(adjusted_prev,(paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Strata/NoBoot/Pred",extension_save,i,".txt")))
    
    plot=ggplot(data=adjusted_prev,aes(x=n,y=adj.rate,group=1))
    plot+geom_point(color="gray60")+
      scale_x_date()+geom_smooth(se=F,color="black",span=0.3)+
      aes(x=n,y=adj.rate,group=1)+xlab("Date")+scale_y_continuous(labels=scales::percent)+
      ylab("Predicted prevalence")+ylim(0,0.03)
    ggsave(paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Strata/NoBoot/NewAdj_",i,modeltype,SCAD,"_NoCI.png"),device="png",dpi=300)
  }
}
fwrite(flowchart,paste0("/proj/sens2020559/COVID-19/Results/9_model_building",sensitivity,".txt"))
print(paste0("9 model building finished",modeltype,sensitivity,SCAD))
