#This file selects a PCR-test per person for the model building.
#First, PCR and antibody tests are defined. Then individuals with PCR- and antibody tests the same day are seen
#as unreliable and excluded. If several updates are made the same individual and day, the last update is choosen.
#Only PCR-tests with conclusive result (positive or negative) are counted. Each individual can contribute with max 1 test,
#which is chosen at random from the tests that remains.
source("globalArgs.R")

set.seed(10000)
library("data.table",lib.loc="/sw/apps/R_packages/3.6.0/rackham")

if (new_model=="new_model") data=fread("/proj/sens2020559/COVID-19/OriginalData/ModelBuilding/covid_test.txt")
if (new_model=="") data=fread("/proj/sens2020559/COVID-19/OriginalData/Current_SWE/covid_test.txt")
flowchart=cbind("Number of rows in test file",length(data[,patient_id]))
data[,updated_at:=substr(updated_at,1,22)]
data[,updated_at:=gsub("\\+00",".00",updated_at)] #removed 20201031
data[,update:=as.POSIXct(updated_at,format="%Y-%m-%d %H:%M:%OS")]
data[,update:=format(update,"%Y-%m-%d %H:%M:%OS2")]
data[,Date:=as.Date(date_taken_specific,format="%Y-%m-%d")]

data[,antibody:=0]
data[grep("blod",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("blood",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("antikr",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("stick",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("kapill",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("stack i",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("immun",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("IgG",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("Imuni",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("Finger",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("IgM",mechanism,ignore.case=TRUE),antibody:=1] 
data[grep("Venprov",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("armv",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("anitkropp",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("kapill",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("Kaplär",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("Serologiskt",mechanism,ignore.case=TRUE),antibody:=1]
data[grep("venös",mechanism,ignore.case=TRUE),antibody:=1]

data[,pcr:=0]
data[grep("swab",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("pinne",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("svalg",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("svalj",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("tops",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("spit_tube",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("spott",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("Naso",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("hals",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("saliv",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("PCR",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("sputum",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("Nose",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("näs",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("Nadophar",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("throat",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("Nasalt/Oralt",mechanism,ignore.case=TRUE),pcr:=1]
data[grep("region Skånes testkit",mechanism,ignore.case=TRUE),pcr:=1]

test_data_uncertain=data.table(unique(data[is.na(Date),.(patient_id,date_taken_between_start,date_taken_between_end,result,antibody,pcr,update,updated_at)]))
if (new_model=="new_model") fwrite(test_data_uncertain,"/proj/sens2020559/COVID-19/MyData/test_data_uncertain.txt")

data=data[Date>as.Date("2019-12-31")]
data=data[!is.na(Date),]

data[,antibody_max:=lapply(.SD,max,na.rm=TRUE),by=.(patient_id,Date),.SDcols="antibody"]
data[,pcr_max:=lapply(.SD,max,na.rm=TRUE),by=.(patient_id,Date),.SDcols="pcr"]
table(data[,result])
data=data[!(antibody_max==1 & pcr_max==1),]
flowchart=rbind(flowchart,cbind("After removing individuals with antibody and PCR tests same day",length(data[,patient_id])))

antibody_data=unique(data[antibody==1,.(patient_id,antibody)]) #result,
flowchart=rbind(flowchart,cbind("Number of patients with antibody tests",length(antibody_data[,patient_id])))
if (new_model=="new_model") fwrite(antibody_data,"/proj/sens2020559/COVID-19/MyData/antibody_data.txt")
pcr_data=unique(data[pcr==1,.(patient_id,pcr)])
flowchart=rbind(flowchart,cbind("Number of patients with PCR-tests",length(antibody_data[,patient_id])))
if (new_model=="new_model") fwrite(pcr_data,"/proj/sens2020559/COVID-19/MyData/pcr_data.txt")

data=data[pcr==1 | antibody==1,]
flowchart=rbind(flowchart,cbind("Number of rows with PCR- or antibody tests",length(data[,patient_id])))
data=data[,N2:=.N,by=.(patient_id,update)]
data=data[!(N2>1),] #making sure there is a clearly defined last update
flowchart=rbind(flowchart,cbind("After removing obs. with no clearly defined last update",length(data[,patient_id])))

#there can be several app updates describing the same test. If so, we take the last update.
data=data[order(patient_id,Date,update),]
data=data[,N:=.N,by=.(patient_id,Date)]
data[,temp:=1]
data[,csum:=cumsum(temp),by=.(patient_id,Date)]
data=data[csum==N,]
flowchart=rbind(flowchart,cbind("After removing updates prior to the last update per patient and date",length(data[,patient_id])))
data[,csum:=NULL]
data[,N:=NULL]
data[,N2:=NULL]
if (new_model=="new_model") fwrite(data,"/proj/sens2020559/COVID-19/MyData/data_for_table1c.txt")
data=data[pcr==1,]
flowchart=rbind(flowchart,cbind("After keeping only PCR-tests",length(data[,patient_id])))

names=c('patient_id','Date','result','date_taken_specific')
data=data[,..names]
data=unique(data)
data=data[result=="positive" | result=="negative",] #we're not interested in waiting/failed tests.
flowchart=rbind(flowchart,cbind("After keeping only tests with decisive result",length(data[,patient_id])))
data[,unif:=runif(n=length(data[,patient_id]))]
pid=data[,patient_id]
pid=unique(pid)
if (new_model=="new_model") fwrite(data,"/proj/sens2020559/COVID-19/MyData/covid_tests_all.txt") #used in "sensitivity_analysis (covid-19 tests)"
data[,unif_max:=lapply(.SD,max),by=patient_id,.SDcols="unif"]
data=data[unif==unif_max,]
flowchart=rbind(flowchart,cbind("After selecting only one (random) test per patient for model building",length(data[,patient_id])))
pid=data[,patient_id]
pid=unique(pid)
data[,unif:=NULL]
data[,unif_max:=NULL]
data[result=="positive",covid:=1]
data[result=="negative",covid:=0]

#one version in date-format, one in character
setnames(data,"Date","TestDate")
setnames(data,"date_taken_specific","SymptomDate")
fwrite(data,"/proj/sens2020559/COVID-19/MyData/covid_tests.txt")
if (new_model=="new_model") fwrite(data,"/proj/sens2020559/COVID-19/MyData/covid_tests_model.txt")
if (new_model=="") fwrite(data,"/proj/sens2020559/COVID-19/MyData/covid_tests_external.txt")
fwrite(flowchart,"/proj/sens2020559/COVID-19/Results/3_covid_test_flowchart.txt")
print("Code 3 finished")

rm(antibody_data)
rm(pcr_data)
