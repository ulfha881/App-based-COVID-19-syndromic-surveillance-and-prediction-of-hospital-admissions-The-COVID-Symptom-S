#!/bin/bash -l
#SBATCH -A sens2020559
#SBATCH -p node -n 1
#SBATCH -J job1
#SBATCH -t 72:00:00
##SBATCH -C fat

module load R_packages/3.6.1
cp /proj/sens2020559/COVID-19/Codes/first_settings.R /proj/sens2020559/COVID-19/Codes/globalArgs.R

nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/SWE_population.do"
Rscript /proj/sens2020559/COVID-19/Codes/2_preprocessing_abbrev.R
Rscript /proj/sens2020559/COVID-19/Codes/3_covid_test_file_preprocessing.R
Rscript /proj/sens2020559/COVID-19/Codes/4_merge_covid_assessment_preprocessing.R

sed -i 's/type="county"/type="nationwide"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/5_expand_grid.R
sed -i 's/type="nationwide"/type="county"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/8_intercept_calibration_new.R
##have to run 10 once already here due to "PID_predict"
Rscript /proj/sens2020559/COVID-19/Codes/10_model_building_strata_nationwide.R

sed -i 's/new_model="new_model"/new_model=""/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
sed -i 's/dataset="train_data"/dataset="all_data"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/2_preprocessing_abbrev.R
Rscript /proj/sens2020559/COVID-19/Codes/3_covid_test_file_preprocessing.R
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/Symptoms_within_7_days.do"
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/Table1_20201029.do"

Rscript /proj/sens2020559/COVID-19/Codes/4_merge_covid_assessment_preprocessing.R
Rscript /proj/sens2020559/COVID-19/Codes/4b_symptom_trajectory_graph.R
sed -i 's/type="county"/type="nationwide"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/5_expand_grid.R
sed -i 's/type="nationwide"/type="county"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/5_expand_grid.R
##Rscript /proj/sens2020559/COVID-19/Codes/8_intercept_calibration_new.R
Rscript /proj/sens2020559/COVID-19/Codes/9_model_building_strata.R
Rscript /proj/sens2020559/COVID-19/Codes/10_model_building_strata_nationwide.R
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/CRUSH_preprocessing.do"
##Rscript /proj/sens2020559/COVID-19/Codes/AUC_for_model.R
sed -i 's/subanalysis=""/subanalysis="healthcare"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/10_model_building_strata_nationwide.R
sed -i 's/subanalysis="healthcare"/subanalysis="gender"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/10_model_building_strata_nationwide.R
sed -i 's/subanalysis="gender"/subanalysis=""/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R

sed -i 's/modeltype=""/modeltype="TUP"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/8_intercept_calibration_new.R
Rscript /proj/sens2020559/COVID-19/Codes/9_model_building_strata.R
Rscript /proj/sens2020559/COVID-19/Codes/10_model_building_strata_nationwide.R
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/CRUSH_preprocessing.do"
##Rscript /proj/sens2020559/COVID-19/Codes/AUC_for_model.R
sed -i 's/subanalysis=""/subanalysis="healthcare"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/10_model_building_strata_nationwide.R
sed -i 's/subanalysis="healthcare"/subanalysis="gender"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/10_model_building_strata_nationwide.R
sed -i 's/subanalysis="gender"/subanalysis=""/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R

sed -i 's/modeltype="TUP"/modeltype=""/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
sed -i 's/SCAD=""/SCAD="SCAD"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/8_intercept_calibration_new.R
Rscript /proj/sens2020559/COVID-19/Codes/9_model_building_strata.R
Rscript /proj/sens2020559/COVID-19/Codes/10_model_building_strata_nationwide.R
##Rscript /proj/sens2020559/COVID-19/Codes/AUC_for_model.R
sed -i 's/SCAD="SCAD"/SCAD=""/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R

Rscript /proj/sens2020559/COVID-19/Codes/symptom_table.R
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/NOVUS_preprocessing.do"
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/Figure_4_and_5.do"
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/Figure_6.do"
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/Registers_by_county.do"
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/Correlations_with_hospitalizations_preprocessing.do"
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/HospitalPredictionModel_Cases.do"
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/HospitalPredictionModel.do"

sed -i 's/new_model=""/new_model="new_model"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
sed -i 's/sensitivity=""/sensitivity="sensitivity"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/Sensitivity_analysis_covid_19_tests.do"
sed -i 's/new_model=""/new_model="new_model"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/8_intercept_calibration_new.R
sed -i 's/new_model="new_model"/new_model=""/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
Rscript /proj/sens2020559/COVID-19/Codes/9_model_building_strata.R
Rscript /proj/sens2020559/COVID-19/Codes/10_model_building_strata_nationwide.R

nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/Figures_for_response_letter.do"

sed -i 's/sensitivity="sensitivity"/sensitivity=""/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
sed -i 's/new_model="new_model"/new_model=""/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R
sed -i 's/ukdata=""/ukdata="ukdata"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R

COUNTER_RUN=1
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/English_preprocessing_of_postal_codes.do"
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/English_population.do"
Rscript /proj/sens2020559/COVID-19/Codes/English_first_assessment.R
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/English_hospitalizations.do"

sed -i 's/type="county"/type="region"/g' /proj/sens2020559/COVID-19/Codes/globalArgs.R

for fileread in /proj/sens2020559/georgioray/Splits_week/*.csv; do
  sed -i "s|nofile|${fileread}|g" /proj/sens2020559/COVID-19/Codes/globalArgs.R
  sed -i "s|${COUNTER2}|${fileread}|g" /proj/sens2020559/COVID-19/Codes/globalArgs.R
  COUNTER2="${fileread}"
  Rscript /proj/sens2020559/COVID-19/Codes/2_preprocessing_abbrev.R
  if (("${COUNTER_RUN}"==1)); then 
  nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/Table1_20201029.do"
  fi
  Rscript /proj/sens2020559/COVID-19/Codes/5_expand_grid.R
  Rscript /proj/sens2020559/COVID-19/Codes/9_model_building_strata.R 
  COUNTER_RUN=$((COUNTER_RUN+1))
done

nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/English_regions.do"
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/Correlations_with_hospitalizations_preprocessing.do"
nohup "/proj/sens2020559/stata15/stata-mp" -b do "/proj/sens2020559/COVID-19/Codes/HospitalPredictionModel.do"
