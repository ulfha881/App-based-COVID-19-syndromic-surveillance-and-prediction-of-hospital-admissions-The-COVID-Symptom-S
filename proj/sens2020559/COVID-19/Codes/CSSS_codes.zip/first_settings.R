ukdata="" #"ukdata" if you want to validate in UK dataset, otherwise ""
new_model="new_model" #to generate the prediction model. if new_model="", we don't calibrate the intercept etc.
type="county" #type should be nationwide here unless UK
subanalysis="" #"", "gender", "healthcare". 
sensitivity="" #"", "sensitivity" (removing tests with divergent test results within +/-10 days.
SCAD="" #"" or "SCAD"
modeltype="" #"" or "TUP"
dataset="train_data" #train_data or all_data
reps=5 #bootstrap repetitions in the AUC_for_model file.
#I've put the three files in a folder called /proj/sens2020559/COVID-19/OriginalData/Current/
UK_files=list.files(path="/proj/sens2020559/georgioray/Splits_week/")
filereader="nofile"