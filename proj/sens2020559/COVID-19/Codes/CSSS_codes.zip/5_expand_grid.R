#CREATES FILES WITH EVERY POSSIBLE COMBINATION OF USER AND DATE, FOR USING WITH LAST OBSERVATION CARRIED FORWARD.
#We only keep maximum seven days after the latest real assessment per user.
#The actual LOCF of the symptoms themselves is carried out in files 8_intercept_calibration-10_model_building_strata_nationwide.
source("globalArgs.R")

if (type=="county") folder="CountyPred"
if (type=="nationwide") folder="Nationwide"
if (type=="region") folder="Region"

library("data.table")
library("haven")
library("lubridate")
library("glmnet")
library("pROC")
library("ggplot2")
library("zoo")

#erase possible previous results, and create a new version of the folder
#unlink(paste0("/proj/sens2020559/COVID-19/MyData/Combinations/",folder),recursive=TRUE)
#dir.create(paste0("/proj/sens2020559/COVID-19/MyData/Combinations/",folder))

#created in "2_preprocessing_abbrev"
data_main=fread("/proj/sens2020559/COVID-19/MyData/FullPredictionData.txt")
if (type=="nationwide") data_main[,nationwide:=1] #That is, only one level.

data_main[,(type):=lapply(.SD,as.factor),.SDcols=type] #re-assign as factor for looping
levels<-levels(data_main[,get(type)])
last_update=max(data_main[,ymd(updated_at)])
if (ukdata=="ukdata") first_update=min(data_main[,ymd(updated_at)]) #a min date for expanding grid needs to be set for UK, since the file is chopped into several parts.

#the loop creates one text file for each level of the choosen type.
for (i in levels){
  grid_data=NULL #otherwise runs into memory storage problems on Bianca
  category_data=NULL
  data_main=fread("/proj/sens2020559/COVID-19/MyData/FullPredictionData.txt")
  if (type=="nationwide") data_main[,nationwide:=1] #That is, only one level.
  category_data=data_main[get(type)==(i),]
  data_main=NULL
  category_data[,updated_at:=ymd(updated_at)]

    if (ukdata!="ukdata"){
    category_data=data.table(category_data[updated_at>ymd("20200503"),])
    updated_at=seq(from=ymd("20200504"),to=last_update,by=1)
  }
  if (ukdata=="ukdata") updated_at=seq(from=first_update,to=last_update,by=1) #ADDED 20211104
  patient_id=unique(category_data[,patient_id]) #vector with all patient_ids for expand.grid
  names<-c('patient_id','updated_at')
  category_data=category_data[,..names]
  category_data=unique(category_data)
  flowchart=cbind(paste0("Number of days with assessment updates ",i),length(category_data[,patient_id]))
  flowchart=rbind(flowchart,cbind(paste0("Number of patients with assessment updates ",i),length(patient_id)))

  category_data[,present:=1] #indicator for whether there is an actual update at that specific time point
  setkey(category_data,'patient_id','updated_at')
  grid_data=unique(data.table(expand.grid(updated_at,patient_id))) #creates all possible combinations...
  patient_id=NULL
  updated_at=NULL
  setnames(grid_data,'Var2','patient_id')
  setnames(grid_data,'Var1','updated_at')
  
  #merges the dataset for specific county/postcode with the "all combinations"-data.
  #then keeps only dates within 7 days from latest update.
  category_data=merge(category_data,grid_data,all=TRUE,by=c('patient_id','updated_at'))
  category_data=unique(category_data)
  flowchart=rbind(flowchart,cbind(paste0("Number of all possible combinations ",i),length(category_data[,patient_id])))
  category_data[is.na(present),present:=0]
  flowchart=rbind(flowchart,cbind(paste0("Of which present in real data ",i),length(category_data[present==1,patient_id])))
  flowchart=rbind(flowchart,cbind(paste0("Of which not present in real data ",i),length(category_data[present==0,patient_id])))

  #tokeep here represents the latest date with an actual assessment. So we keep only dates 7 days or less after latest actual assessment.
  category_data[present==1,tokeep:=updated_at]
  category_data=category_data[order(patient_id,updated_at),]
  category_data[,tokeep:=na.locf(tokeep,na.rm=FALSE),by=patient_id]
  category_data[,filter:=as.numeric(updated_at-tokeep)]
  pid=as.vector(unique(category_data[,patient_id]))
  category_data=category_data[filter<8,] #keep only the first seven days
  flowchart=rbind(flowchart,cbind(paste0("Final size of dataset ",i),length(category_data[,patient_id])))
  patient_id=unique(category_data[,patient_id])
  flowchart=rbind(cbind(paste0("Number of patients in final dataset (should be same as before expand.grid) ",i),length(patient_id)))
  category_data[,tokeep:=NULL]
  fwrite(category_data,paste0("/proj/sens2020559/COVID-19/MyData/Combinations/",folder,"/",i,".txt"))
  #a smaller file for the 8_intercept_calibration_new-code due to R:s problems with memory and garbage collection.
  if (type=="nationwide" & ukdata=="" & new_model=="new_model"){
      category_data=category_data[updated_at<ymd("20200610") & updated_at>ymd("20200515"),] 
      fwrite(category_data,paste0("/proj/sens2020559/COVID-19/MyData/Combinations/",folder,"/",i,"calib",".txt"))
  }
}
fwrite(flowchart,"/proj/sens2020559/COVID-19/Results/5_expand_grid_flowchart.txt")
print("Code 5 finished")
rm(category_data)
rm(pid)
rm(patient_id)
rm(grid_data)
warnings()