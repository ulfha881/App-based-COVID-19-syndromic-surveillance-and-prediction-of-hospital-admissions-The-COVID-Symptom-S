#Here the covid test data is merged with the assessment and patient data used for model building.
#To be matched, an individual needs to have at least one report in the assessment file 7 or fewer days prior to the test date
#(or on the test date itself).If an individual has several such reports, (s)he retains only the symptom observations on the day closest to the test date.
#If no symptom is reported on that date, the individual is excluded from model building.
source("globalArgs.R")

library("data.table")
library("haven")
library("lubridate")

#covid_tests is created in the "3_covid_test_file_preprocessing.R"-code.
if (new_model=="new_model") covid_data=fread("/proj/sens2020559/COVID-19/MyData/covid_tests.txt")
if (new_model=="") covid_data=fread("/proj/sens2020559/COVID-19/MyData/covid_tests_external.txt")
covid_data[,SymptomDate:=ymd(SymptomDate)]
write_dta(covid_data,"/proj/sens2020559/COVID-19/MyData/Data0.dta")
flowchart=cbind("Number of participants in test file",length(covid_data[,patient_id]))

#generates seven files with lags. If the covid test is taken on July 11th, "lag_1" sets the date as July 10th,
#so it matches with the symptoms the person had July 10th. Thus, "lag_1" contains the symptoms the person had the day BEFORE the test.
for (i in 1:7){
    covid_data[,SymptomDate:=SymptomDate-i]  
    write_dta(covid_data,paste0("/proj/sens2020559/COVID-19/MyData/Data_lag_",i,".dta"))
    covid_data[,SymptomDate:=SymptomDate+i]  
}

#"Assessment_for_model" contains all symptom information (file created in 2_preprocessing.R).
if (new_model=="new_model") assess_data=fread("/proj/sens2020559/COVID-19/MyData/Assessment_for_model")
if (new_model=="") assess_data=fread("/proj/sens2020559/COVID-19/MyData/Assessment_for_model_validation")
covid_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/Data0.dta"))
#merges test data and symptom data on id and date.
setnames(assess_data,"updated_at","SymptomDate")
assess_data[,SymptomDate:=ymd(SymptomDate)]
setkeyv(assess_data,c('patient_id','SymptomDate'))
setkeyv(covid_data,c('patient_id','SymptomDate'))
covid_data=covid_data[assess_data,nomatch=0]
flowchart=rbind(flowchart,cbind("Number of participants with assessment same date as test",length(covid_data[,patient_id])))
covid_data[,Day:=0]
write_dta(covid_data,"/proj/sens2020559/COVID-19/MyData/MainData0.dta")
rm(covid_data)

##this part merges all of the lags testdata files with the symptoms file.
for (i in 1:7){
    covid_lag_data=data.table(read_dta(paste0("/proj/sens2020559/COVID-19/MyData/Data_lag_",i,".dta")))
    covid_lag_data[,Day:=(i)]
    setkeyv(covid_lag_data,c('patient_id','SymptomDate'))
    covid_lag_data=covid_lag_data[assess_data,nomatch=0]
    flowchart=rbind(flowchart,cbind(paste0("Number of participants with assessment",i,"days before test"),length(covid_lag_data[,patient_id])))
    write_dta(covid_lag_data,paste0("/proj/sens2020559/COVID-19/MyData/MainData_lag_",i,".dta"))
    rm(covid_lag_data)
}
rm(assess_data)
joint_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/MainData0.dta"))
#...adds lagged joins to main dataset, making sure each individual only retains one measurement
#(the measurement closest to the test date)
for (i in 1:7){
  lag_data=data.table(read_dta(paste0("/proj/sens2020559/COVID-19/MyData/MainData_lag_",i,".dta")))
  joint_data=data.table(rbind(joint_data,lag_data))
  rm(lag_data)
  joint_data[,last_assess:=min(Day),by=patient_id]
  joint_data=joint_data[last_assess==Day,]
  joint_data[,last_assess:=NULL]
  flowchart=rbind(flowchart,cbind(paste0("Number of participants when including assessment",i,"days before test"),length(joint_data[,patient_id])))
}
symptoms=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
           'chest_pain','hoarse_voice','headache','eye_soreness',
           'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
           'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath','loss_of_smell') 

#other_symptoms removed 20201120 as test

joint_data[,any_symptom_positive:=apply(.SD,1,max,na.rm=TRUE),by=1:nrow(joint_data),.SDcols=symptoms]
ToKeep=c('patient_id','TestDate','covid','any_symptom_positive')
joint_data=joint_data[any_symptom_positive==1,]
flowchart=rbind(flowchart,cbind(paste0("After retaining only symptomatics in the test file"),length(joint_data[,patient_id])))
joint_data=unique(joint_data)
flowchart=rbind(flowchart,cbind(paste0("After dropping potential duplicates"),length(joint_data[,patient_id])))

#patient_data_for_model is generated in 2_preprocessing
if (new_model=="new_model") patient_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/patient_data_for_model.dta"))
if (new_model=="") patient_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/patient_data_for_model_validation.dta"))
setkey(patient_data,'patient_id')
setkey(joint_data,'patient_id')
model_data=joint_data[patient_data,nomatch=0]
flowchart=rbind(flowchart,cbind(paste0("After dropping individuals not in patient file"),length(joint_data[,patient_id])))
#only save these if we use the model building dataset
if (new_model=="new_model"){
  write_dta(model_data,"/proj/sens2020559/COVID-19/MyData/ModelData.dta")
  fwrite(flowchart,"/proj/sens2020559/COVID-19/Results/4_merge_covid_assessment_preprocessing_flowchart.txt")
}
#used in AUC_for_model.R (the external validation part)
if (new_model=="") write_dta(model_data,"/proj/sens2020559/COVID-19/MyData/ExternalValidationData.dta")
rm(joint_data)

print("Code 4 finished")


