#BUILDS THE REGRESSION MODEL, CALIBRATES IT USING THE INTERCEPT FROM 8_intercept_calibration.R,
#AND THEN USING IT FOR PREDICTIONS ON NATIONAL LEVEL
#ALSO USES DIRECT STANDARDIZATION FOR REWEIGHTING COEFFICIENTS BY STRATA.
source("globalArgs.R")
if (type=="county") folder="Nationwide"

set.seed(10000) #seed for LASSO lamda cross-validation to remain consistent
sens=0.7

source("/home/ulfha881/Desktop/COVID-19/Codes/model_building.R")
library("data.table")

#here we store the intercept generated in "8_intercept_calibration".
new_intercept=as.numeric(fread(paste0("/proj/sens2020559/COVID-19/MyData/Calibrations",modeltype,sensitivity,SCAD,".txt")))

#see 8_intercept_calibration for details of this function
model_building()
model2$a0=new_intercept #re-calibration of intercept
if (SCAD=="SCAD") model2$beta[1]=model2$a0

predict_data=fread("/proj/sens2020559/COVID-19/MyData/FullPredictionData.txt")
pid_predict=predict_data[,.(patient_id)]

predict_data=predict_data[county!="",]
predict_data[,county:=as.factor(county)]
names<-levels(predict_data[,county])

predict_data[,SymptomDate:=as_date(updated_at)]

symptom_list=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
               'chest_pain','hoarse_voice','headache','eye_soreness',
               'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
               'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath','loss_of_smell') 

for (i in symptom_list){
   predict_data[,tmp:=lapply(.SD,mean),by=SymptomDate,.SDcols=i]
   tmp_data=predict_data[,.(SymptomDate,tmp)]
   tmp_data=unique(tmp_data)
   tmp_data[,tmp:=as.numeric(tmp)]
   tmp_data[,SymptomDate:=ymd(SymptomDate)]
   tmp_data[,SymptomDate:=as_date(SymptomDate)]
   plot=ggplot(data=tmp_data,aes(x=SymptomDate,y=tmp)) #,group=1
   plot+geom_point()+scale_x_date()
   ggsave(paste0("/proj/sens2020559/COVID-19/Results/",i,".png"),device="png",dpi=300)
   predict_data[,tmp:=NULL]
   tmp_data=NULL
}

predict_data[,SymptomDate:=as.numeric(SymptomDate)]
pid=unique(predict_data[,patient_id])

#for (vary in variables){
  #  predict_data[get(vary)<0,(vary):=0]
  #}

if (modeltype=="TUP"){
	m=ns(predict_data[,SymptomDate],knots=c(knots[1],knots[2],knots[3],knots[4],knots[5]),Boundary.knots=c(bknots[1],bknots[2]))
 	predict_data[,time_spl1:=..m[,1]]
 	predict_data[,time_spl2:=..m[,2]]
  	predict_data[,time_spl3:=..m[,3]]
  	predict_data[,time_spl4:=..m[,4]]
  	predict_data[,time_spl5:=..m[,5]]
  	predict_data[,time_spl6:=..m[,6]]
}
  flowchart=cbind(paste0("Number of rows in",type,i),length(predict_data[,patient_id]))
  flowchart=rbind(flowchart,cbind(paste0("Number of patients in",type,i),length(pid)))

  columns=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
            'chest_pain','hoarse_voice','loss_of_smell','headache','eye_soreness',
            'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
            'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath',
            'gender','age','updated_at','patient_id','group','county','healthcare_professional')
  if (modeltype=="TUP") columns=c(columns,timevar)

  setkey(predict_data,'patient_id')
  predict_data=predict_data[,..columns]
  predict_data=na.omit(predict_data)

  #create interaction terms
  for (var in variables){
    predict_data[,paste0("loss_",var):=loss_of_smell*get(var)]
  }
  #remove when less than 100 in smallest category
  
  predict_data=na.omit(predict_data)
  updated_at=predict_data[,updated_at]
  county=predict_data[,county]
  patient_id=predict_data[,patient_id]
  healthcare_professional=predict_data[,healthcare_professional]
  group=predict_data[,group]
  predict_data[,updated_at:=NULL]
  predict_data[,patient_id:=NULL]
  predict_data[,group:=NULL]
  predict_data[,county:=NULL]
  predict_data[,healthcare_professional:=NULL]
  predict_data=as.matrix(predict_data)
  pred_tmp=predict(model2,predict_data,type="response")
  saveRDS(model2,paste0("/proj/sens2020559/COVID-19/MyData/ModelNat",SCAD,sensitivity,modeltype,".rds"))
  predict_data=data.table(predict_data)
  predict_data[,updated_at:=..updated_at]
  predict_data[,group:=..group]
  predict_data[,pred:=..pred_tmp]
  predict_data[,patient_id:=..patient_id]
  predict_data[,county:=..county]
  
  predict_data[,healthcare_professional:=..healthcare_professional]
  
  predict_data[,symptomatic:=0]
    for (value in symptom_list){
      predict_data[get(value)!=0 & is.na(get(value))==FALSE,symptomatic:=1] #!=0 eftersom ålder och ev. tid ej 0/1.  
    }
  
  predict_data[symptomatic==0,pred:=0]
  predict_data[,symptomatic:=NULL]
  
  #data generated in "expand.grid.R".
  postal_data=fread(paste0("/proj/sens2020559/COVID-19/MyData/Combinations/Nationwide/1.txt"))
  postal_data[,updated_at:=ymd(updated_at)]
  postal_data[,patient_id:=as.character(patient_id)]
  predict_data[,updated_at:=ymd(updated_at)]
  predict_data[,patient_id:=as.character(patient_id)]
  
  flowchart=cbind(paste0("No of individuals, prediction data",type,i),length(unique(predict_data[,patient_id])))
  flowchart=rbind(flowchart,cbind(paste0("No of rows, prediction data",type,i),length(predict_data[,patient_id])))

  if (subanalysis=="healthcare"){
    predict_data[,group:=NULL]
    predict_data[age>17 & age<40 & gender==0 & healthcare_professional==0,group:=1]
    predict_data[age>17 & age<40 & gender==1 & healthcare_professional==0,group:=2]
    predict_data[age>39 & age<65 & gender==0 & healthcare_professional==0,group:=3]
    predict_data[age>39 & age<65 & gender==1 & healthcare_professional==0,group:=4]
    predict_data[age>64 & gender==0 & healthcare_professional==0,group:=5]
    predict_data[age>64 & gender==1 & healthcare_professional==0,group:=6]
    predict_data[age>17 & age<40 & gender==0 & healthcare_professional==1,group:=7]
    predict_data[age>17 & age<40 & gender==1 & healthcare_professional==1,group:=8]
    predict_data[age>39 & age<65 & gender==0 & healthcare_professional==1,group:=9]
    predict_data[age>39 & age<65 & gender==1 & healthcare_professional==1,group:=10]
    predict_data[age>64 & gender==0 & healthcare_professional==1,group:=11]
    predict_data[age>64 & gender==1 & healthcare_professional==1,group:=12]
  }
  if (subanalysis=="gender"){
    predict_data[age>17 & age<40 & gender==0,group:=1]
    predict_data[age>17 & age<40 & gender==1,group:=2]
    predict_data[age>39 & age<65 & gender==0,group:=3]
    predict_data[age>39 & age<65 & gender==1,group:=4]
    predict_data[age>64 & gender==0,group:=5]
    predict_data[age>64 & gender==1,group:=6]
  }
    
  county_data=unique(predict_data[,.(patient_id,county)])
  predict_data=merge(predict_data,postal_data,all=TRUE,by=c('patient_id','updated_at'))
  flowchart=rbind(flowchart,paste0("No of individuals, prediction data after merge",type,i),length(unique(predict_data[,patient_id])))
  flowchart=rbind(flowchart,cbind(paste0("No of rows, prediction data after merge",type,i),length(predict_data[,patient_id])))
  
  predict_data=predict_data[order(patient_id,updated_at),]
  predict_data[,pred:=na.locf(pred,na.rm=FALSE),by=patient_id]
  predict_data[,group:=na.locf(group,na.rm=FALSE),by=patient_id]
  predict_data[,county:=as.character(county)]

  predict_data[,county:=NULL]
  predict_data=merge(predict_data,county_data,by='patient_id')
  predict_data[,category:=county]
  predict_data[,category:=as.factor(category)]
  
 predict_data=predict_data[updated_at>ymd("20200509") & updated_at<ymd("20210211"),]
  
  names2=c('pred','updated_at','patient_id','group','category')
  predict_data=predict_data[,..names2]
  predict_data[,group:=as.factor(group)]
  predict_data[,updated_at:=as.factor(updated_at)]
  
  fwrite(predict_data,"/proj/sens2020559/COVID-19/MyData/prdata2.txt") #stämmer med 9_model_building
  
  flowchart=rbind(flowchart,paste0("No of individuals, prediction data after LOCF",type,i),length(unique(predict_data[,patient_id])))
  flowchart=rbind(flowchart,cbind(paste0("No of individuals, prediction data after LOCF",type,i),length(predict_data[,patient_id])))
  
  #If there are at least 200 individuals in a county/postal area, we run the reweighting, create the graphs etc.
  #This first part generates the number of individuals and summed predicted probabilities for each day.
  pid=unique(predict_data[,patient_id])

  length=length(pid)
  if (length>199){
    reweighing_data=matrix(nrow=0,ncol=5)
    for (laen in names){ #triple loop, by county, strata and date. 
      #gives a summary of number of users and sum of predicted probabilities for each of these combinations, 
      #and collects them in the matrix "reweighing_data"
      for (m in levels(predict_data[,group])){
        data3=predict_data[group==(m) & category==(laen),]
        for (j in levels(predict_data[,updated_at])){
          tmp=data.table(data3[updated_at==(j),])
          tmp[,pred:=sum(pred)] #input to ageadjust.direct function is a sum, not a mean.
          pid=unique(tmp[,patient_id])     
          tmp[,N:=length(pid)]
          tmp[,patient_id:=NULL]
          tmp=as.matrix(unique(tmp)) #group, category and updated_at unique, pred is common to all (due to sum). So is N.
          reweighing_data=rbind(reweighing_data,tmp)
        }
      }
    }
  }

    #...uses "ageadjust.direct" to extract adjusted rates with confidence interval.
  #creates a matrix with these values + the number of participants in total and in each strata (all "cbinds")
  if (length>199){
    pop=fread(paste0("/proj/sens2020559/COVID-19/MyData/pop",type,".txt")) #this "type" should be "county"
    #unlike in code 9, we don't just select a category this time...all counties are used.
    reweighing_data=data.table(reweighing_data)
    reweighing_data[,updated_at:=as.factor(updated_at)]
    reweighing_data[,pred:=as.numeric(pred)]
    reweighing_data[,N:=as.numeric(N)]
    #if we run a subanalysis with gender or healthcare we don't reweight the predictions. Instead we store the crude values
    #in a text file for further analysis/plotting in the Stata file "Graphs_for_hospitalizations_and_gender.do".
    if (subanalysis=="healthcare" | subanalysis=="gender"){
      raw_pred=data.table(reweighing_data)
      raw_pred[,pred:=as.numeric(pred)]
      raw_pred[,N:=as.numeric(N)]
      raw_pred[,pred:=sum(pred),by=.(updated_at,group)]
      raw_pred[,N:=sum(N),by=.(updated_at,group)]
      raw_pred[,perc:=pred/N]
      raw_pred[,category:=NULL]
      raw_pred=unique(raw_pred)
      fwrite(raw_pred,paste0("/proj/sens2020559/COVID-19/MyData/Nationwide/RawPredictionsByGroup",subanalysis,modeltype,sensitivity,SCAD,".txt"))
    }
    #...for each date, generate weighted predictions.
    pop[,population:=as.numeric(population)]
    adjusted_prev=matrix(nrow=0,ncol=6)
    for (n in levels(reweighing_data[,updated_at])){
      temp=reweighing_data[updated_at==(n),]
      temp=temp[order(category,group),]
      pop=pop[order(category,group),]
        temp[,pred:=pred/sens] #adjustment for sensitivity
        temp[,group:=as.numeric(group)]
        pop[,group:=as.numeric(group)]

        temp=merge(temp,pop,by=c("group","category"))
        
        tmp=ageadjust.direct(count=temp[,pred],pop=temp[,N],stdpop=temp[,population])
        temp=temp[,N:=sum(N)]
        N=temp[,N]
        tmp=t(tmp) #the results from ageadjust.direct has to be transposed into the right format. From column vector to row vector.
        tmp=cbind(tmp,n) #adds the date to the row
        tmp=cbind(tmp,N)
        adjusted_prev=rbind(adjusted_prev,tmp) #...and appends the row to the other rows.
      }
    }
    #generates a graph for each county/postal code. 
    #Rates and CI:s are put to NA for days with less than 5 participants in the smallest strata
    adjusted_prev=data.table(adjusted_prev)
    adjusted_prev=adjusted_prev[,n:=ymd(n)]
    adjusted_prev[,n:=as_date(n)]
    variab=c('crude.rate','adj.rate','uci','lci','N')
    adjusted_prev=adjusted_prev[,(variab):=lapply(.SD,as.numeric,na.rm=TRUE),.SDcols=variab]
  
    ggplot(data=adjusted_prev)+geom_ribbon(aes(ymin=lci,ymax=uci,x=n),fill="gray",color="gray")+
      geom_line(aes(y=adj.rate,x=n))+geom_point(aes(y=adj.rate,x=n))+scale_x_date()+xlab("Date")+ylab("Predicted prevalence")
    ggsave(paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Strata/NoBoot/Adj_Riket",modeltype,sensitivity,SCAD,subanalysis,".png"),device="png",dpi=1000)
    
    fwrite(adjusted_prev,(paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Strata/NoBoot/Riket",modeltype,sensitivity,SCAD,subanalysis,".txt")))

    plot=ggplot(data=adjusted_prev,aes(x=n,y=adj.rate,group=1))
    plot+geom_ribbon(aes(ymin=lci,ymax=uci),fill="gray80")+geom_point(color="gray60")+
      scale_x_date()+geom_smooth(se=F,color="black",span=0.2)+
      aes(x=n,y=adj.rate,group=1)+xlab("Date")+scale_y_continuous(labels=scales::percent)+
      ylab("Predicted prevalence")
    ggsave(paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Strata/NoBoot/NewAdj",modeltype,sensitivity,SCAD,subanalysis,".png"),device="png",dpi=300)
    
    plot=ggplot(data=adjusted_prev,aes(x=n,y=adj.rate,group=1))
    plot+scale_x_date()+geom_smooth(se=F,color="black",span=0.2)+
      aes(x=n,y=adj.rate,group=1)+xlab("Date")+scale_y_continuous(labels=scales::percent)+
      ylab("Predicted prevalence")+geom_point(color="gray60")
    ggsave(paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Strata/NoBoot/NewAdj_NoCI",modeltype,sensitivity,SCAD,subanalysis,".png"),device="png",dpi=300)
    plot=ggplot(data=adjusted_prev,aes(x=n,y=adj.rate,group=1))
    plot+scale_x_date()+geom_smooth(se=F,color="black",span=0.2)+
      aes(x=n,y=crude.rate,group=1)+xlab("Date")+scale_y_continuous(labels=scales::percent)+
      ylab("Predicted prevalence")+geom_point(color="gray60")
    ggsave(paste0("/proj/sens2020559/COVID-19/MyData/",folder,"/Strata/NoBoot/Crude_NoCI",modeltype,sensitivity,SCAD,subanalysis,".png"),device="png",dpi=300)
    pid_predict=unique(pid_predict)
    write_dta(pid_predict,paste0("/proj/sens2020559/COVID-19/MyData/PID_predict",sensitivity,new_model,ukdata,subanalysis,".dta"))
    
fwrite(flowchart,paste0("/proj/sens2020559/COVID-19/Results/10_model_building_strata_nationwide",sensitivity,new_model,subanalysis,".txt"))
print(paste0("10 finished",modeltype,sensitivity,SCAD,subanalysis))