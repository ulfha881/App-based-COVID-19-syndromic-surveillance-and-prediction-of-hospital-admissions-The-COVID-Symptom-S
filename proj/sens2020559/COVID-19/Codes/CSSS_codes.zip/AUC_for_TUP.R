print("AUC FOR TUP:")
set.seed(10000) #seed for LASSO lamda cross-validation to remain consistent

#choose type before running the code (county or postcode)
#type="three_digit_postcode"
sens=0.7

library("data.table",lib.loc="/sw/apps/R_packages/3.6.0/rackham")
library("haven")
library("lubridate")
library("glmnet")
library("pROC")
library("ggplot2")
library("zoo")
library("scales")
library("epitools")
library("mltools")
library("dplyr")
library("caret")
library("splines")
library("PRROC")
library("boot")

eval=""
def_sym=""

symptom_list=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
               'chest_pain','hoarse_voice','headache','eye_soreness',
               'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
               'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath','loss_of_smell') 

#here we store the intercept generated in "8_intercept_calibration".
new_intercept=as.numeric(fread("/proj/sens2020559/COVID-19/MyData/Calibrations.txt"))

flowchart=numeric(0)

model_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/ModelData_Current.dta"))

pid=fread("/proj/sens2020559/COVID-19/MyData/patient_id_all.txt")
setnames(pid,'V1','patient_id')
model_data=merge(model_data,pid,by='patient_id')
write_dta(model_data,"/proj/sens2020559/COVID-19/MyData/ModelData_Current_Update.dta")

model_data[,SymptomDate:=ymd(SymptomDate)]
print(summary(model_data[,SymptomDate]))

model_data[,SymptomDate:=as.numeric(SymptomDate)]

print("MAKE SURE MODEL IS 1jan")
print(summary(model_data[,SymptomDate]))
model_data=data.table(model_data)
model_data=model_data[SymptomDate<ymd("20210101"),]
print("MAKE SURE MODEL IS 31dec")
print(summary(model_data[,SymptomDate]))

pid_model=model_data[,patient_id]

#model_data[,SymptomDate>ymd("20200601") & SymptomDate<ymd("20200901")]
#model_data[,SymptomDate:=as.numeric(SymptomDate)]
#print(model_data[,SymptomDate])

#model_data=na.omit(model_data)
print("?????")
head(model_data)
m=ns(model_data[,SymptomDate],df=6)
print("JVLA HELVETE")
model_data[,time_spl1:=..m[,1]]
model_data[,time_spl2:=..m[,2]]
model_data[,time_spl3:=..m[,3]]
model_data[,time_spl4:=..m[,4]]
model_data[,time_spl5:=..m[,5]]
model_data[,time_spl6:=..m[,6]]

#model_data[,loss_time_int1:=loss_of_smell*time_spl1]
#model_data[,loss_time_int2:=loss_of_smell*time_spl2]
#model_data[,loss_time_int3:=loss_of_smell*time_spl3]
#model_data[,loss_time_int4:=loss_of_smell*time_spl4]
print("T1")
#make sure same position of knots for prediction data
knots=attr(m,"knots")
bknots=attr(m,"Boundary.knots")
columns=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
          'chest_pain','hoarse_voice','loss_of_smell','headache','eye_soreness',
          'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
          'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath',
          'covid','gender','age','time_spl1','time_spl2','time_spl3','time_spl4','time_spl5','time_spl6','SymptomDate')
#,'healthcare_professional','ndi','utomlands','Density'


variables=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
            'chest_pain','hoarse_voice','headache','eye_soreness',
            'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
            'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath','gender','age',
            'time_spl1','time_spl2','time_spl3','time_spl4','time_spl5','time_spl6')

model_data=model_data[,..columns]

print("T3")

#create interaction terms
for (var in variables){
  model_data[,paste0("loss_",var):=loss_of_smell*get(var)]
}
print("hhhh")
#print(str(model_data))
#table=model_data[,lapply(.SD,sum,na.rm=TRUE)]
data=model_data
model_data=NULL
print("gggg")

#model_data[,SymptomDate:=(SymptomDate-mean(SymptomDate))/sd(SymptomDate)]
#cross-validation of AUC, 10 groups. For each iteration, there's also an internal CV on the training data,
#to get the right lambda.
data=data.table(data)
data[,index:=1:length(data[,SymptomDate])]
print("WORKS?")
print(head(data[,index],n=20))
bootstrap_internal_val<-function(data,index){
data2=data[index,]
data[,group:=runif(length(data[,age]))]
data[,group:=as.factor(cut(group,breaks=10))]
eval=numeric(0)

for (i in levels(data[,group])){
  train_data=data[group!=(i),]
  test_data=data[group==(i),]
  covid_train=as.factor(train_data[,covid])
  covid_test=as.factor(test_data[,covid])
  updated_at=test_data[,SymptomDate]
  #print(head(updated_at))
  train_data[,covid:=NULL]
  test_data[,covid:=NULL]
  train_data[,group:=NULL]
  test_data[,group:=NULL]
  test_data[,SymptomDate:=NULL]
  train_data[,SymptomDate:=NULL]
  test_data[,index:=NULL]
  train_data[,index:=NULL]
  
  train_data=as.matrix(train_data) #glmnet needs matrix format
  test_data=as.matrix(test_data)
  model=cv.glmnet(x=train_data,y=covid_train,family='binomial')
  model2=glmnet(train_data,covid_train,family='binomial',lambda=model$lambda.min)
  
  pred_tmp=as.numeric(predict(model2,test_data,type="response"))
  tmp=cbind(covid_test,pred_tmp,updated_at)
  eval=rbind(tmp,eval)
}
#AUC
eval=data.table(eval)
print("DATATAB")
setnames(eval,"covid_test","covid")
AUC=auc(eval[,covid],eval[,pred_tmp])
AUC_ci=ci.auc(eval[,covid],eval[,pred_tmp])

#str(AUC)
print("AUC:")
print(AUC)
print(AUC_ci)

#notera att as.factor gör så att covid==2 är positiva
class1<-eval[covid==2,pred_tmp]
class0<-eval[covid==1,pred_tmp]

print("DOES THIS WORK")
#PRROC package, 20211022
#ska vi lägga till bootstrap?
AUC2=roc.curve(scores.class0=class1,scores.class1=class0) #make sure that we get the same result
#PRROC package, 20211022
PRC2=pr.curve(scores.class0=class1,scores.class1=class0) #make sure that we get the same result
print("AUC,make sure same as above")
print(AUC2)
print("PRCAUC")
print(PRC2)
assign("eval",eval,envir=.GlobalEnv)
assign("model2",model2,envir=.GlobalEnv)
return(PRC2$auc.integral)
}

AUC_vector=numeric(0)

print("WITHOUT BOOTSTRAP")
bootstrap_internal_val(data,data[,index])

results=boot(data=data,statistic=bootstrap_internal_val,R=250)
print("BOOTSTRAP AND CI")
print(boot.ci(results,type="norm"))

print("BOOTSTRAP AGAIN....")
bootstrap_internal_val(data,data[,index])

#eval[,cutpoints:=cut_number(eval[,pred_tmp],10)]
eval[,cutpoints:=ntile(eval[,pred_tmp],10)]

eval[,mean_pred:=lapply(.SD,mean),by=cutpoints,.SDcols='pred_tmp']
eval[,covid:=as.numeric(covid)]
eval[,var_pred:=lapply(.SD,var),by=cutpoints,.SDcols='covid']
eval[,N:=.N,by=cutpoints]
eval[,se_pred:=sqrt(var_pred/N)]
eval[,mean_prob:=exp(mean_pred)/(1+exp(mean_pred))]
print("HEAD1")
print(table(eval[,covid]))
eval[,covid:=covid-1]
eval[,mean_covid:=lapply(.SD,mean),by=cutpoints,.SDcols='covid']
print("HEAD2")
ggplot(data=eval)+geom_point(aes(y=(mean_covid),x=(mean_prob)))+
  geom_errorbar(aes(ymin=mean_covid-1.96*se_pred,ymax=mean_covid+1.96*se_pred,x=mean_prob))+geom_abline(intercept=0,slope=1,linetype="dashed")+
  xlab("Expected")+ylab("Observed")
ggsave("/proj/sens2020559/COVID-19/Results/Calibration_TUP",device="tiff",dpi=300)

eval=data.table(eval)
eval2=eval[,.(mean_covid,mean_prob,se_pred)]
eval=data.frame(eval)
fwrite(eval2,"/proj/sens2020559/COVID-19/MyData/Calibration_TUP.txt")
eval2=NULL
print("???")
#eval[,updated_at:=ymd(updated_at)]


model_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/ModelData.dta"))

print("BOUNDARY")
print(summary(model_data[,SymptomDate]))

#ändring 20211029...känns väl givet? missar jag något?
m=ns(model_data[,SymptomDate],knots=c(knots[1],knots[2],knots[3],knots[4],knots[5]),Boundary.knots=c(bknots[1],bknots[2]))
#m=ns(model_data[,SymptomDate],df=6)

model_data[,time_spl1:=..m[,1]]
model_data[,time_spl2:=..m[,2]]
model_data[,time_spl3:=..m[,3]]
model_data[,time_spl4:=..m[,4]]
model_data[,time_spl5:=..m[,5]]
model_data[,time_spl6:=..m[,6]]

#model_data[,loss_time_int1:=loss_of_smell*time_spl1]
#model_data[,loss_time_int2:=loss_of_smell*time_spl2]
#model_data[,loss_time_int3:=loss_of_smell*time_spl3]
#model_data[,loss_time_int4:=loss_of_smell*time_spl4]
print("T1")
#make sure same position of knots for prediction data
knots=attr(m,"knots")
bknots=attr(m,"Boundary.knots")
columns=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
          'chest_pain','hoarse_voice','loss_of_smell','headache','eye_soreness',
          'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
          'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath',
          'covid','gender','age','time_spl1','time_spl2','time_spl3','time_spl4','time_spl5','time_spl6','SymptomDate')
#,'healthcare_professional','ndi','utomlands','Density'

variables=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
            'chest_pain','hoarse_voice','headache','eye_soreness',
            'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
            'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath','gender','age',
            'time_spl1','time_spl2','time_spl3','time_spl4','time_spl5','time_spl6')

model_data=model_data[,..columns]

#create interaction terms
for (var in variables){
  model_data[,paste0("loss_",var):=loss_of_smell*get(var)]
}

#model_data[,pred_tmp:=pr]
model_data=model_data[SymptomDate>ymd("2020-12-31"),]
model_data[,SymptomDate:=NULL]
model_data=na.omit(model_data)

print("MD")
print(str(model_data))
print(model2$coefficients)
print(model2$beta)
model_data[,index:=1:length(model_data[,loss_gender])]
print(head(model_data))
bootstrap_internal_val<-function(data,index){
model_data2=model_data[index,]
model_data2[,index:=NULL]
covid=model_data2[,covid]
model_data2[,covid:=NULL]
model_data2=as.matrix(model_data2)
pr=as.numeric(predict(model2,model_data2,type="response"))
model_data2=data.table(model_data2)
print("HUH")
print(sum(is.na(pr)))
print("HUH3")
AUC=auc(covid,pr)
AUC_ci=ci.auc(covid,pr)
print("AUC:")
print(AUC)
print(AUC_ci)

print(table(covid),useNA="always")

class1<-pr[covid==1]
class0<-pr[covid==0]

print("DOES THIS WORK 2")
print(head(class1))
print(head(class0))
#PRROC package, 20211022
#ska vi lägga till bootstrap?
AUC2=roc.curve(scores.class0=class1,scores.class1=class0) #make sure that we get the same result
#PRROC package, 20211022
PRC2=pr.curve(scores.class0=class1,scores.class1=class0) #make sure that we get the same result
print("AUC,make sure same as above")
print(AUC2)
print("PRCAUC")
print(PRC2)
assign("pr",pr,.GlobalEnv)
assign("covid",covid,.GlobalEnv)
return(PRC2$auc.integral)
}
print("WITHOUT BOOTSTRAP")
bootstrap_internal_val(model_data,model_data[,index])

results=boot(data=model_data,statistic=bootstrap_internal_val,R=250)
print("BOOTSTRAP AND CI")
print(boot.ci(results,type="norm"))

print("STRANGE")
model_data[,prob_tmp:=..pr]
model_data[,covid:=..covid]
#print(table(model_data[,prob_tmp]))
model_data=model_data[order(prob_tmp),]
#model_data=model_data[,log_prob:=log(prob_tmp)]
model_data[,cutpoints:=ntile(model_data[,prob_tmp],10)]
summary(model_data[,prob_tmp])
#model_data[,cutpoints:=cut(prob_tmp,breaks=quantile(model_data[,prob_tmp],probs=seq(0,1,by=0.1),include.lowest=TRUE))]
model_data[,mean_prob:=lapply(.SD,mean),by=cutpoints,.SDcols='prob_tmp']
model_data[,covid:=as.numeric(covid)]
model_data[,var_prob:=lapply(.SD,var),by=cutpoints,.SDcols='covid']
model_data[,N:=.N,by=cutpoints]
model_data[,se_pred:=sqrt(var_prob/N)]
#model_data[,mean_prob:=exp(mean_pred)/(1+exp(mean_pred))]
print("WTF")
#print(table(model_data[,covid]))
#model_data[,covid:=covid-1]
model_data[,mean_covid:=lapply(.SD,mean),by=cutpoints,.SDcols='covid']

ggplot(data=model_data)+geom_point(aes(y=(mean_covid),x=(mean_prob)))+
  geom_errorbar(aes(ymin=mean_covid-1.96*se_pred,ymax=mean_covid+1.96*se_pred,x=mean_prob))+geom_abline(intercept=0,slope=1,linetype="dashed")+
  xlab("Expected")+ylab("Observed")+xlim(0, 0.7)+ylim(0, 0.7)
ggsave("/proj/sens2020559/COVID-19/Results/Calibration_External_TUP",device="tiff",dpi=300)

eval=model_data[,.(mean_covid,mean_prob,se_pred)]
fwrite(eval,"/proj/sens2020559/COVID-19/MyData/Calibration_External_TUP.txt")


  data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/CRUSH_data_tup.dta"))
  print(head(data))
  gender=data[,gender]
  data[,patient_id:=NULL]
  data[,gender:=as.numeric(gender)]
  print(table(data[,(loss_of_smell)]))
  data[,loss_of_smell:=as.numeric(loss_of_smell)]
  print(table(data[,(loss_of_smell)]))
  print("WTF?")
  
  m=ns(data[,survey_date],knots=c(knots[1],knots[2],knots[3],knots[4],knots[5]),Boundary.knots=c(bknots[1],bknots[2]))
  
  data[,time_spl1:=..m[,1]]
  data[,time_spl2:=..m[,2]]
  data[,time_spl3:=..m[,3]]
  data[,time_spl4:=..m[,4]]
  data[,time_spl5:=..m[,5]]
  data[,time_spl6:=..m[,6]]
  
  data[,survey_date:=NULL]
  
  print(str(data))
  print("OK??")
  data[,(variables):=lapply(.SD,as.numeric),.SDcols=variables]
  print(warnings())
  print(str(data))
  
  for (var in variables){
    print(var)
    print(table(data[,get(var)]))
    data[,paste0("loss_",var):=loss_of_smell*get(var)]
  }
  
  print("WHATS THis THEMN")
  print("???")
  
  print(head(data))
  print(model2$beta)
  #pr=as.numeric(predict(model2,data,type="response"))
  data=data.table(data)
  data[,index:=1:length(data[,loss_age])]
  bootstrap_internal_val<-function(data,index){
    data2=data[index,]
    data2[,index:=NULL]
    covid=data2[,covid]
    data2[,covid:=NULL]
    data2=as.matrix(data2)
    pr=as.numeric(predict(model2,data2,type="response"))
  #model_data=data.table(model_data)
  
  # roc(response=covid,predictor=pr)
  # png("/proj/sens2020559/COVID-19/Results/ROC_curve.png",width=700,height=700)
  # plot(roc)
  # dev.off()
  
    cutoff=as.numeric(pr>0.2)
    conf_matrix=table(cutoff,covid)
    print("CONFUSION")
    print(conf_matrix)
    print(sensitivity(conf_matrix))
    print(specificity(conf_matrix))
  
    AUC=auc(covid,pr)
    AUC_ci=ci.auc(covid,pr)
    print("AUC:")
    print(AUC)
    print(AUC_ci)
    
    class1<-pr[covid==1]
    class0<-pr[covid==0]
  
    #PRROC package, 20211022
    #ska vi lägga till bootstrap?
    AUC2=roc.curve(scores.class0=class1,scores.class1=class0) #make sure that we get the same result
    #PRROC package, 20211022
    PRC2=pr.curve(scores.class0=class1,scores.class1=class0) #make sure that we get the same result
    print("AUC,make sure same as above")
    print(AUC2)
    print("PRCAUC")
    print(PRC2)
    assign("pr",pr,.GlobalEnv)
    assign("covid",covid,.GlobalEnv)
    return(PRC2$auc.integral)
  }
  
  print("WITHOUT BOOTSTRAP")
  bootstrap_internal_val(data,data[,index])
  
  results=boot(data=data,statistic=bootstrap_internal_val,R=250)
  print("BOOTSTRAP AND CI")
  print(boot.ci(results,type="norm"))

  print("BOOTSTRAP AGAIN, CRUSH")
  bootstrap_internal_val(data,data[,index])  
  
  d2=cbind(covid,pr)
  
  print("STRANGE")
  data=data.table(data)
  data[,prob_tmp:=..pr]
  data[,covid:=..covid]
  #print(table(model_data[,prob_tmp]))
  data=data[order(prob_tmp),]
  #model_data=model_data[,log_prob:=log(prob_tmp)]
  data[,cutpoints:=ntile(data[,prob_tmp],10)]
  summary(data[,prob_tmp])
  #model_data[,cutpoints:=cut(prob_tmp,breaks=quantile(model_data[,prob_tmp],probs=seq(0,1,by=0.1),include.lowest=TRUE))]
  data[,mean_prob:=lapply(.SD,mean),by=cutpoints,.SDcols='prob_tmp']
  data[,covid:=as.numeric(covid)]
  data[,var_prob:=lapply(.SD,var),by=cutpoints,.SDcols='covid']
  data[,N:=.N,by=cutpoints]
  data[,se_pred:=sqrt(var_prob/N)]
  #model_data[,mean_prob:=exp(mean_pred)/(1+exp(mean_pred))]
  print("WTF")
  #print(table(model_data[,covid]))
  #model_data[,covid:=covid-1]
  data[,mean_covid:=lapply(.SD,mean),by=cutpoints,.SDcols='covid']

  data=data[,.(mean_covid,mean_prob,se_pred)] 
  data=unique(data)
  #data[,se_pred:=se_pred+rnorm(n=length(data[,mean_prob]),mean=0,sd=0.0001)]
  data[,lb:=pmax(0.000001,mean_covid-1.96*se_pred)]
  data[,ub:=mean_covid+1.96*se_pred]
  ggplot(data=data)+geom_point(aes(y=(mean_covid),x=(mean_prob)))+
    geom_errorbar(aes(ymin=lb,ymax=ub,x=mean_prob))+geom_abline(intercept=0,slope=1,linetype="dashed")+
    xlab("Expected")+ylab("Observed")+xlim(0, 0.7)+ylim(0, 0.7)
  ggsave("/proj/sens2020559/COVID-19/Results/Calibration_External_TUP_CRUSH",device="tiff",dpi=300)
  
  fwrite(data,"/proj/sens2020559/COVID-19/MyData/Calibration_CRUSH.txt")