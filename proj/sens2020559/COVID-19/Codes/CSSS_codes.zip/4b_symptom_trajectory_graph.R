#Here the covid test data is merged with the other two data files.
#The covid test data is still in Stata format (since the file is small).
library("data.table")
library("haven")
library("lubridate")
library("ggplot2")
rm(list=ls())

#covid_tests is created in the "3_covid_test_file_preprocessing.do"-code.
covid_data=fread("/proj/sens2020559/COVID-19/MyData/covid_tests.txt")
#important: Stata date format is not the same as R date format. R starts at 1970.
#therefore the SymptomDate variable must be imported to R as string.
covid_data[,SymptomDate:=ymd(SymptomDate)]
write_dta(covid_data,"/proj/sens2020559/COVID-19/MyData/Data0.dta")

flowchart=cbind("Number of participants in test file",length(covid_data[,patient_id]))

#generates seven files with lags. If the covid test is taken on July 11th, "lag_1" sets the date as July 10th,
#so it matches with the symptoms the person had July 10th. Thus, "lag_1" contains the symptoms the person had the day BEFORE the test.
for (i in 1:15){
  covid_data[,SymptomDate:=SymptomDate-i]  
  write_dta(covid_data,paste0("/proj/sens2020559/COVID-19/MyData/Data_lag_",i,".dta"))
  covid_data[,SymptomDate:=SymptomDate+i]  
}

for (i in 1:15){
  covid_data[,SymptomDate:=SymptomDate+i]  
  write_dta(covid_data,paste0("/proj/sens2020559/COVID-19/MyData/Data_lead_",i,".dta"))
  covid_data[,SymptomDate:=SymptomDate-i]  
}

#"Assessment_for_model" contains all symptom information (file created in 2_preprocessing.R).
assess_data=fread("/proj/sens2020559/COVID-19/MyData/Assessment_for_model")
covid_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/Data0.dta"))

#merges test data and symptom data on id and date.
setnames(assess_data,"updated_at","SymptomDate")
assess_data[,SymptomDate:=ymd(SymptomDate)]
setkeyv(assess_data,c('patient_id','SymptomDate'))
setkeyv(covid_data,c('patient_id','SymptomDate'))
covid_data=covid_data[assess_data,nomatch=0]

flowchart=rbind(flowchart,cbind("Number of participants with assessment same date as test",length(covid_data[,patient_id])))

#this part merges all of the lags and leads testdata files with the symptoms file.
covid_data[,Day:=0]
write_dta(covid_data,"/proj/sens2020559/COVID-19/MyData/MainData0.dta")
rm(covid_data)

#...saves lagged joins between test data and symptom data
for (i in 1:15){
  covid_lag_data=data.table(read_dta(paste0("/proj/sens2020559/COVID-19/MyData/Data_lag_",i,".dta")))
  covid_lag_data[,Day:=-(i)]
  setkeyv(covid_lag_data,c('patient_id','SymptomDate'))
  covid_lag_data=covid_lag_data[assess_data,nomatch=0]
  flowchart=rbind(flowchart,cbind(paste0("Number of participants with assessment",i,"days before test"),length(covid_lag_data[,patient_id])))
  write_dta(covid_lag_data,paste0("/proj/sens2020559/COVID-19/MyData/MainData_lag_",i,".dta"))
  rm(covid_lag_data)
}
for (i in 1:15){
  covid_lead_data=data.table(read_dta(paste0("/proj/sens2020559/COVID-19/MyData/Data_lead_",i,".dta")))
  covid_lead_data[,Day:=(i)]
  setkeyv(covid_lead_data,c('patient_id','SymptomDate'))
  covid_lead_data=covid_lead_data[assess_data,nomatch=0]
  flowchart=rbind(flowchart,cbind(paste0("Number of participants with assessment",i,"days before test"),length(covid_lead_data[,patient_id])))
  write_dta(covid_lead_data,paste0("/proj/sens2020559/COVID-19/MyData/MainData_lead_",i,".dta"))
  rm(covid_lead_data)
}
rm(assess_data)

joint_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/MainData0.dta"))
#...adds lagged joins to main dataset, making sure each individual only retains one measurement
#(the measurement closest to the test date)
for (i in 1:15){
  lag_data=data.table(read_dta(paste0("/proj/sens2020559/COVID-19/MyData/MainData_lag_",i,".dta")))
  joint_data=data.table(rbind(joint_data,lag_data))
 }
for (i in 1:15){
  lead_data=data.table(read_dta(paste0("/proj/sens2020559/COVID-19/MyData/MainData_lead_",i,".dta")))
  joint_data=data.table(rbind(joint_data,lead_data))
}

write_dta(joint_data,"/proj/sens2020559/COVID-19/MyData/ModelSymptoms.dta")


joint_data[,covid_tot:=max(covid),by=patient_id]
joint_data=joint_data[covid_tot==1,]

joint_data[,mean_loss:=mean(loss_of_smell),by=Day]
joint_data[,mean_throat:=mean(sore_throat),by=Day]
joint_data[,mean_muscle:=mean(unusual_muscle_pains),by=Day]
joint_data[,mean_fever:=mean(fever),by=Day]
joint_data[,mean_cough:=mean(persistent_cough),by=Day]

joint_data=joint_data[,.(Day,mean_loss,mean_throat,mean_muscle,mean_fever,mean_cough)]
joint_data=unique(joint_data)

ggplot(data=joint_data)+geom_line(size=1.1,aes(y=mean_loss,x=Day,color="red"))+
geom_line(size=1.5,aes(y=mean_throat,x=Day,color="blue"))+
geom_line(size=1.5,aes(y=mean_muscle,x=Day,color="orange"))+
geom_line(size=1.5,aes(y=mean_fever,x=Day,color="black"))+
xlab("Day after test")+scale_y_continuous(labels=scales::percent)+
ylab("% with symptoms")+geom_vline(xintercept=0)+
scale_color_discrete(name="symptoms",labels=c('fever','sore throat','unusual muscle pain','loss of smell'))+
scale_x_continuous(breaks=c(-15,-12,-9,-6,-3,0,3,6,9,12,15))
ggsave(paste0("/proj/sens2020559/COVID-19/Results/LoS.png"),device="png",dpi=300)