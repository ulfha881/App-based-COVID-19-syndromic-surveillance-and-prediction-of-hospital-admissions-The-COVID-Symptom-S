set.seed(10000) #seed for LASSO lamda cross-validation to remain consistent
source("globalArgs.R")
sens=0.7

library("data.table",lib.loc="/sw/apps/R_packages/3.6.0/rackham")
library("haven")
library("lubridate")
library("glmnet")
library("pROC")
library("ggplot2")
library("zoo")
library("scales")
library("epitools")
library("mltools")
library("dplyr")
library("caret")
library("MLmetrics")
library("PRROC")
library("boot")
library("ncvreg") #added 20211102

#call function for model building.
source("/home/ulfha881/Desktop/COVID-19/Codes/model_building.R")

#see 8_intercept_calibration for details of this function
model_building()

#We start with the external validation - the discrimination and calibration of the individuals after 20201231
model_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/ExternalValidationData.dta"))

if (modeltype=="TUP"){
  m=ns(model_data[,SymptomDate],knots=c(knots[1],knots[2],knots[3],knots[4],knots[5]),Boundary.knots=c(bknots[1],bknots[2]))
  model_data[,time_spl1:=..m[,1]]
  model_data[,time_spl2:=..m[,2]]
  model_data[,time_spl3:=..m[,3]]
  model_data[,time_spl4:=..m[,4]]
  model_data[,time_spl5:=..m[,5]]
  model_data[,time_spl6:=..m[,6]]
}

model_data=model_data[SymptomDate>ymd("2020-12-31"),]
model_data[,SymptomDate:=NULL]

columns=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
          'chest_pain','hoarse_voice','loss_of_smell','headache','eye_soreness',
          'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
          'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath',
          'covid','gender','age')
if (modeltype=="TUP") columns=c(columns,timevar)
model_data=model_data[,..columns]

#create interaction terms ("variables" are created in the "model_building.R" code included in the beginning of the script)
for (var in variables){
  model_data[,paste0("loss_",var):=loss_of_smell*get(var)]
}

model_data=na.omit(model_data)
model_data[,index:=1:length(model_data[,loss_gender])]
bootstrap_external_val<-function(model_data,index){
  model_data2=model_data[index,]
  model_data2[,index:=NULL]
  covid=model_data2[,covid]
  model_data2[,covid:=NULL]
  model_data2=as.matrix(model_data2)
  pr=as.numeric(predict(model2,model_data2,type="response"))
  model_data2=data.table(model_data2)
  AUC=auc(covid,pr)
  AUC_ci=ci.auc(covid,pr)

  class1<-pr[covid==1]
  class0<-pr[covid==0]

  #PRROC package, 20211022
  AUC2=roc.curve(scores.class0=class1,scores.class1=class0) #make sure that we get the same result
  PRC2=pr.curve(scores.class0=class1,scores.class1=class0) #make sure that we get the same result
  assign("pr",pr,.GlobalEnv)
  assign("covid",covid,.GlobalEnv)
  assign("AUC",AUC,.GlobalEnv)
  assign("AUC_ci",AUC_ci,.GlobalEnv)
  return(PRC2$auc.integral)
}

model_data=data.table(model_data)

bootstrap_external_val(model_data,model_data[,index])
results=boot(data=model_data,statistic=bootstrap_external_val,R=reps)
PRC2_CI_external=as.numeric(boot.ci(results,type="norm")$normal)
PRC2_external=bootstrap_external_val(model_data,model_data[,index])
AUC_external=as.numeric(AUC)
AUC_CI_external=as.numeric(AUC_ci)

#Creating calibration plot for the external evaluation
model_data[,prob_tmp:=..pr]
model_data[,covid:=..covid]
model_data=model_data[order(prob_tmp),]
model_data[,cutpoints:=ntile(model_data[,prob_tmp],10)]
model_data[,mean_prob:=lapply(.SD,mean),by=cutpoints,.SDcols='prob_tmp']
model_data[,covid:=as.numeric(covid)]
model_data[,var_prob:=lapply(.SD,var),by=cutpoints,.SDcols='covid']
model_data[,N:=.N,by=cutpoints]
model_data[,se_pred:=sqrt(var_prob/N)]
model_data[,mean_covid:=lapply(.SD,mean),by=cutpoints,.SDcols='covid']

ggplot(data=model_data)+geom_point(aes(y=(mean_covid),x=(mean_prob)))+
  geom_errorbar(aes(ymin=mean_covid-1.96*se_pred,ymax=mean_covid+1.96*se_pred,x=mean_prob))+geom_abline(intercept=0,slope=1,linetype="dashed")+
  xlab("Expected")+ylab("Observed")+xlim(0, 0.7)+ylim(0, 0.7)
ggsave(paste0("/proj/sens2020559/COVID-19/Results/Calibration_External",modeltype,sensitivity,SCAD),device="tiff",dpi=300)
model_data=model_data[,.(mean_covid,mean_prob,se_pred)]
fwrite(model_data,paste0("/proj/sens2020559/COVID-19/MyData/Calibration_External",modeltype,sensitivity,SCAD,".txt"))

#Internal validation
model_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/ModelData_Current.dta"))
model_data=na.omit(model_data)

if (modeltype=="TUP"){
  m=ns(model_data[,SymptomDate],knots=c(knots[1],knots[2],knots[3],knots[4],knots[5]),Boundary.knots=c(bknots[1],bknots[2]))
  model_data[,time_spl1:=..m[,1]]
  model_data[,time_spl2:=..m[,2]]
  model_data[,time_spl3:=..m[,3]]
  model_data[,time_spl4:=..m[,4]]
  model_data[,time_spl5:=..m[,5]]
  model_data[,time_spl6:=..m[,6]]
}
model_data=model_data[,..columns] #timevar already added for TUP

#create interaction terms
for (var in variables){
  model_data[,paste0("loss_",var):=loss_of_smell*get(var)]
}

#cross-validation of AUC, 10 groups. For each iteration, there's also an internal CV on the training data,
#to get the right lambda.
model_data=data.table(model_data)
model_data[,index:=1:length(model_data[,loss_of_smell])]
bootstrap_internal_val<-function(model_data,index,bootstr){
  data2=data.table(model_data[index,])
  data2[,group:=runif(length(data2[,age]))]
  data2[,group:=as.factor(cut(group,breaks=10))]
  eval=numeric(0)

  for (i in levels(data2[,group])){
      train_data=data2[group!=(i),]
      test_data=data2[group==(i),]
      covid_train=as.factor(train_data[,covid])
      covid_test=as.factor(test_data[,covid])
      train_data[,covid:=NULL]
      test_data[,covid:=NULL]
      train_data[,group:=NULL]
      test_data[,group:=NULL]
      train_data[,index:=NULL]
      test_data[,index:=NULL]
      
      train_data=as.matrix(train_data) #glmnet needs matrix format
      test_data=as.matrix(test_data)
      
      if (SCAD!="SCAD"){
        model=cv.glmnet(x=train_data,y=covid_train,family='binomial')
        model_internal=glmnet(train_data,covid_train,family='binomial',lambda=model$lambda.min)
      }
      if (SCAD=="SCAD"){
        model=cv.ncvreg(X=train_data,y=covid_train,family='binomial',nfolds=10,penalty="SCAD")
        model_internal=ncvreg(X=train_data,y=covid_train,family='binomial',lambda=model$lambda.min,penalty="SCAD")
      }
      pred_tmp=as.numeric(predict(model_internal,test_data))
      tmp=cbind(covid_test,pred_tmp)
      eval=rbind(tmp,eval)
  }

  eval=data.table(eval)
  setnames(eval,"covid_test","covid")
  AUC=auc(eval[,covid],eval[,pred_tmp])
  AUC_ci=ci.auc(eval[,covid],eval[,pred_tmp])
  
  #notera att as.factor gör så att covid==2 är positiva
  class1<-eval[covid==2,pred_tmp]
  class0<-eval[covid==1,pred_tmp]
  
  #PRROC package, 20211022
  AUC2=roc.curve(scores.class0=class1,scores.class1=class0) #make sure that we get the same result
  #PRROC package, 20211022
  PRC2=pr.curve(scores.class0=class1,scores.class1=class0) #make sure that we get the same result
  assign("pr",pr,.GlobalEnv)
  assign("covid",covid,.GlobalEnv)
  assign("AUC",AUC,.GlobalEnv)
  assign("AUC_ci",AUC_ci,.GlobalEnv)
  assign("eval",eval,envir=.GlobalEnv) #to global environment for calibration plots to work.
  return(PRC2$auc.integral)
}

bootstrap_internal_val(model_data,model_data[,index])
results=boot(data=model_data,statistic=bootstrap_internal_val,R=reps)
PRC2_CI_internal=as.numeric(boot.ci(results,type="norm")$normal)
PRC2_internal=bootstrap_internal_val(model_data,model_data[,index])
AUC_internal=as.numeric(AUC)
AUC_CI_internal=AUC_ci

eval=data.table(eval)
eval[,cutpoints:=ntile(eval[,pred_tmp],10)]

eval[,mean_pred:=lapply(.SD,mean),by=cutpoints,.SDcols='pred_tmp']
eval[,covid:=as.numeric(covid)]
eval[,var_pred:=lapply(.SD,var),by=cutpoints,.SDcols='covid']
eval[,N:=.N,by=cutpoints]
eval[,se_pred:=sqrt(var_pred/N)]
eval[,mean_prob:=exp(mean_pred)/(1+exp(mean_pred))]
eval[,covid:=covid-1]
eval[,mean_covid:=lapply(.SD,mean),by=cutpoints,.SDcols='covid']

ggplot(data=eval)+geom_point(aes(y=(mean_covid),x=(mean_prob)))+
geom_errorbar(aes(ymin=mean_covid-1.96*se_pred,ymax=mean_covid+1.96*se_pred,x=mean_prob))+geom_abline(intercept=0,slope=1,linetype="dashed")+
xlab("Expected")+ylab("Observed")
ggsave(paste0("/proj/sens2020559/COVID-19/Results/Calibration_Internal",modeltype,sensitivity,SCAD),device="tiff",dpi=300)

eval2=eval[,.(mean_covid,mean_prob,se_pred)]
fwrite(eval2,paste0("/proj/sens2020559/COVID-19/MyData/Calibration_Internal",modeltype,sensitivity,SCAD,".txt"))
eval2=NULL

if (modeltype=="") model_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/CRUSH_data.dta"))
if (modeltype=="TUP"){
  model_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/CRUSH_data_tup.dta"))
  m=ns(model_data[,survey_date],knots=c(knots[1],knots[2],knots[3],knots[4],knots[5]),Boundary.knots=c(bknots[1],bknots[2]))
  model_data[,time_spl1:=..m[,1]]
  model_data[,time_spl2:=..m[,2]]
  model_data[,time_spl3:=..m[,3]]
  model_data[,time_spl4:=..m[,4]]
  model_data[,time_spl5:=..m[,5]]
  model_data[,time_spl6:=..m[,6]]
}
model_data=model_data[,..columns] #timevar already added for TUP

gender=model_data[,gender]
model_data[,patient_id:=NULL]
model_data[,gender:=as.numeric(gender)]
model_data[,loss_of_smell:=as.numeric(loss_of_smell)]
model_data[,(variables):=lapply(.SD,as.numeric),.SDcols=variables]
for (var in variables){
  model_data[,paste0("loss_",var):=loss_of_smell*get(var)]
}

model_data=data.table(model_data)
model_data[,index:=1:length(model_data[,loss_age])]

bootstrap_external_val(model_data,model_data[,index])
results=boot(data=model_data,statistic=bootstrap_external_val,R=reps)
PRC2_CI_CRUSH=boot.ci(results,type="norm")$normal
PRC2_CRUSH=bootstrap_external_val(model_data,model_data[,index])
AUC_CRUSH=as.numeric(AUC)
AUC_CI_CRUSH=as.numeric(AUC_ci)

model_data=data.table(model_data)
model_data[,prob_tmp:=..pr]
model_data[,covid:=..covid]
model_data=model_data[order(prob_tmp),]
model_data[,cutpoints:=ntile(model_data[,prob_tmp],10)]
model_data[,mean_prob:=lapply(.SD,mean),by=cutpoints,.SDcols='prob_tmp']
model_data[,covid:=as.numeric(covid)]
model_data[,var_prob:=lapply(.SD,var),by=cutpoints,.SDcols='covid']
model_data[,N:=.N,by=cutpoints]
model_data[,se_pred:=sqrt(var_prob/N)]
model_data[,mean_covid:=lapply(.SD,mean),by=cutpoints,.SDcols='covid']
  
ggplot(data=model_data)+geom_point(aes(y=(mean_covid),x=(mean_prob)))+
geom_errorbar(aes(ymin=mean_covid-1.96*se_pred,ymax=mean_covid+1.96*se_pred,x=mean_prob))+geom_abline(intercept=0,slope=1,linetype="dashed")+
xlab("Expected")+ylab("Observed")+xlim(0, 0.7)+ylim(0, 0.7)
ggsave(paste0("/proj/sens2020559/COVID-19/Results/Calibration_External_CRUSH",modeltype,sensitivity,SCAD),device="tiff",dpi=300)
  
model_data=data.table(model_data)
model_data=model_data[,.(mean_covid,mean_prob,se_pred)]
fwrite(model_data,paste0("/proj/sens2020559/COVID-19/MyData/Calibration_CRUSH",modeltype,sensitivity,SCAD,".txt"))

#############Creates a combined file with AUC and PRAUC and confidence intervals for internal, external and CRUSH#####
area=rbind(AUC_internal,AUC_external)
area=rbind(area,AUC_CRUSH)

au_ci=rbind(AUC_CI_internal,AUC_CI_external)
au_ci=rbind(au_ci,AUC_CI_CRUSH)

pr_area=rbind(PRC2_internal,PRC2_external)
pr_area=rbind(pr_area,PRC2_CRUSH)

pr_ci=rbind(PRC2_CI_internal,PRC2_CI_external)
pr_ci=rbind(pr_ci,PRC2_CI_CRUSH)

names=c("Internal","External","CRUSH")

output=data.table(data.frame(names=names,AUC=area,AUC_CI=au_ci,PRAUC=pr_area,PRAUC_CI=pr_ci))
fwrite(output,paste0("/proj/sens2020559/COVID-19/Results/AUC",modeltype,sensitivity,SCAD,".txt"))
####################################################
rm(model_data)