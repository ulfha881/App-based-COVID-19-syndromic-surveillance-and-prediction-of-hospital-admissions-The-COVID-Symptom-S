#Calibrates the model intercept so the nationwide prevalence estimate on the prediction data matches the Public Health Survey at the end of May. 
#This can be done for the main model or for the TUP model.And using a LASSO (SCAD="") or SCAD (SCAD="SCAD") model.
#For the main data, there's also a sensitivity analysis with removal of covid tests which has another covid test within +/-10 and with a different result
#The calibration is done by bisection.

source("globalArgs.R")

set.seed(10000) #seed for LASSO lamda cross-validation to remain consistent

sens=0.7
#call function for model building
source("model_building.R")
model_building()

#The rest of the code uses bisection to calibrate the intercept
calib=numeric(0)
calib_inter=numeric(0)
upper_shrink=-7 #an arbitrary, very low number to start with
lower_shrink=-2.5
tol=10000
rm(model_data)

#Nationwide data for LOCF generated in "5_expand.grid.R".
postal_data=fread(paste0("/proj/sens2020559/COVID-19/MyData/Combinations/Nationwide/1calib.txt"))
postal_data[,updated_at:=ymd(updated_at)]
postal_data[,patient_id:=as.character(patient_id)]

##0.00001
#continues re-calibration as long as the tolerance threshold is not met
while(abs(tol)>0.00001){
  new_intercept=(upper_shrink+lower_shrink)/2
  model2$a0=new_intercept
  if (SCAD=="SCAD") model2$beta[1]=model2$a0
  prediction_data=fread("/proj/sens2020559/COVID-19/MyData/PredictionData_Calibration.txt")
  
  prediction_data[,updated_at:=ymd(updated_at)]
  #We only need the prediction for 27th May, but extra days are required due to LOCF.
  if (ukdata=="ukdata") setnames(prediction_data,"region","county")
  prediction_data[,county:=as.factor(county)]
  names<-levels(prediction_data[,county])
  
  #for (vary in variables){
  #  prediction_data[get(vary)<0,(vary):=0]
  #}
  
  if (modeltype=="TUP"){
    m=ns(prediction_data[,updated_at],knots=c(knots[1],knots[2],knots[3],knots[4],knots[5]),Boundary.knots=c(bknots[1],bknots[2]))
    prediction_data[,time_spl1:=..m[,1]]
    prediction_data[,time_spl2:=..m[,2]]
    prediction_data[,time_spl3:=..m[,3]]
    prediction_data[,time_spl4:=..m[,4]]
    prediction_data[,time_spl5:=..m[,5]]
    prediction_data[,time_spl6:=..m[,6]]
  }
  
  #columns updated with patient_id and day (updated_at) in prediction data. No need to update the "variable" object, though.
  columns=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
            'chest_pain','hoarse_voice','loss_of_smell','headache','eye_soreness',
            'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
            'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath',
            'gender','age','updated_at','patient_id','group','county')
  if (modeltype=="TUP") columns=c(columns,timevar)
  
  prediction_data=prediction_data[,..columns]
  
  #create interaction terms with loss of smell
  for (i in variables){
    prediction_data[,paste0("loss_",i):=loss_of_smell*get(i)]
  }
  prediction_data=na.omit(prediction_data)
  
  #The LASSO matrix must only include variables actually used in the model.
  #therefore this strange solution, in which variables needed later are temporarily stored as vectors
  #(and re-admitted to the main dataset after the predictions has been generated).
  updated_at=prediction_data[,updated_at]
  prediction_data[,updated_at:=NULL]
  patient_id=prediction_data[,patient_id]
  prediction_data[,patient_id:=NULL]
  group=prediction_data[,group]
  prediction_data[,group:=NULL]
  county=prediction_data[,county]
  prediction_data[,county:=NULL]
  
  #LASSO predictions are generated
  prediction_data=as.matrix(prediction_data)
  pred_tmp=predict(model2,prediction_data,type="response")
  saveRDS(model2,paste0("/proj/sens2020559/COVID-19/MyData/ModelInt",SCAD,sensitivity,modeltype,".rds"))
  #..re-admits the vectors with patient_id etc. to the main dataset
  prediction_data=data.table(prediction_data)
  prediction_data[,pred:=..pred_tmp]
  prediction_data[,group:=..group]
  prediction_data[,county:=..county]
  prediction_data[,updated_at:=..updated_at]
  prediction_data[,patient_id:=..patient_id]
  
  #These are the variables that determine if a person is to be defined as "symptomatic" or not. Any of them present=symptomatic, otherwise not.
  symptom_list=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
                 'chest_pain','hoarse_voice','headache','eye_soreness',
                 'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
                 'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath','loss_of_smell') 
  
  #generates the "symptomatic" variable. Asymptomatic individuals gets a covid-probability of 0 assigned by definition.  
  prediction_data[,symptomatic:=0]
  for (value in symptom_list){
    prediction_data[get(value)!=0 & is.na(get(value))==FALSE,symptomatic:=1]
  }
  prediction_data[symptomatic==0,pred:=0]
  prediction_data[,symptomatic:=NULL]
  
  prediction_data=prediction_data[,.(patient_id,updated_at,pred,group,county)]
  prediction_data=unique(prediction_data) #added 20211116 instead of lapply line.
  
  prediction_data[,updated_at:=ymd(updated_at)]
  prediction_data[,patient_id:=as.character(patient_id)]
  
  flowchart=cbind(paste0("No of individuals, prediction data"),length(unique(prediction_data[,patient_id])))
  flowchart=rbind(flowchart,cbind(paste0("No of rows, prediction data"),length(prediction_data[,patient_id])))
  
  county_data=unique(prediction_data[,.(patient_id,county)])
  prediction_data=merge(prediction_data,postal_data,all=TRUE,by=c('patient_id','updated_at'))
  flowchart=rbind(flowchart,paste0("No of individuals, prediction data after merge"),length(unique(prediction_data[,patient_id])))
  flowchart=rbind(flowchart,cbind(paste0("No of rows, prediction data after merge"),length(prediction_data[,patient_id])))
  
  #LOCF is carried out, after getting the data in the right order
  prediction_data=prediction_data[order(patient_id,updated_at),]
  prediction_data[,pred:=na.locf(pred,na.rm=FALSE),by=patient_id]
  prediction_data[,group:=as.integer(max(group,na.rm=TRUE)),by=patient_id]
  #ensures no -Inf for group (after max(...na.rm=TRUE)) and no NA:s for pred in data. Just a precaution.
  prediction_data=prediction_data[group==1 | group==2 | group==3 | group==4,]
  prediction_data=prediction_data[!is.na(pred),]
  
  flowchart=rbind(flowchart,cbind(paste0("No of individuals, prediction data after LOCF"),length(unique(prediction_data[,patient_id]))))
  flowchart=rbind(flowchart,cbind(paste0("No of individuals, prediction data after LOCF"),length(prediction_data[,patient_id])))
  
  prediction_data[,county:=NULL]
  prediction_data=merge(prediction_data,county_data,by='patient_id')
  prediction_data[,category:=county]
  prediction_data[,category:=as.factor(category)]
  #date within the range of the Public Health Survey sampling
  #this selection is carried out late, since earlier predicted values can be relevant too (due to LOCF)
  prediction_data=prediction_data[updated_at==ymd("20200527"),] 
  names2=c('pred','group','patient_id','category')
  prediction_data=prediction_data[,..names2]
  prediction_data=unique(prediction_data)
  prediction_data[,group:=as.factor(group)]
  print("NEW INT")
  print(new_intercept)
  fwrite(prediction_data,"/proj/sens2020559/COVID-19/MyData/prdata.txt") #stämmer med 9_model_building
  
  flowchart=rbind(flowchart,paste0("No of individuals, prediction data after LOCF"),length(unique(prediction_data[,patient_id])))
  flowchart=rbind(flowchart,cbind(paste0("No of individuals, prediction data after LOCF"),length(prediction_data[,patient_id])))
  
  #stores the sum of predicted probabilities + the total number of participants in each strata and county (21 counties*4 strata in total for SWE)
  reweighing_data=matrix(nrow=0,ncol=4)
  for (laen in names){
    for (m in levels(prediction_data[,group])){
      tmp=prediction_data[group==(m) & category==(laen),]
      tmp[,pred:=sum(pred)]
      pid=unique(tmp[,patient_id])
      tmp[,N:=length(pid)]
      tmp[,patient_id:=NULL]
      tmp=as.matrix(unique(tmp))
      reweighing_data=rbind(reweighing_data,tmp)
    }
  }
  
  #if-satser och popregion added 2021-11-02
  if (type!="region") pop=fread(paste0("/proj/sens2020559/COVID-19/MyData/popcounty.txt"))
  if (type=="region") pop=fread(paste0("/proj/sens2020559/COVID-19/MyData/popregion.txt"))
  
  #unlike in code 9, we don't just select a category this time...all counties are used.
  reweighing_data=data.table(reweighing_data)
  fwrite(reweighing_data,"/proj/sens2020559/COVID-19/MyData/rewdata.txt") 
  reweighing_data[,pred:=as.numeric(pred)]
  reweighing_data[,N:=as.numeric(N)]
  reweighing_data[,group:=as.numeric(group)]
  reweighing_data[,pred:=as.numeric(pred)]
  reweighing_data=reweighing_data[order(group),]
  reweighing_data[,pred:=pred/sens] #adjustment for sensitivity
  pop[,population:=as.numeric(population)]
  pop[,group:=as.numeric(group)]
  flowchart=rbind(flowchart,cbind(paste0("No of counties times strata before merge"),length(reweighing_data[,N])))
  reweighing_data=merge(reweighing_data,pop,by=c("group","category"))
  flowchart=rbind(flowchart,cbind(paste0("No of counties times strata after merge"),length(reweighing_data[,N])))
  fwrite(reweighing_data,"/proj/sens2020559/COVID-19/MyData/rewdata2.txt")
  reweighing_data=reweighing_data[order(category,group),] #"," added 20211115
  
  #function for generating confidence intervals for the strata-weighted prevalences
  tmp=ageadjust.direct(count=reweighing_data[,pred],pop=reweighing_data[,N],stdpop=reweighing_data[,population])
  
  #0.7% Public Health Agency estimated prevalence for Sthlm 25-28 May, 70% symptomatic (updated guess!)
  #tmp[2] is the adjusted rate. We want "tol" to be as close to zero as possible.
  #est. sensitivity of 70%
  tol=(tmp[2]-0.003*0.7/sens) 
  
  #re-calibrates intercept (changing the higher or lower bound depending on whether predictions are too high or too low)
  if (tol>0){
    lower_shrink=new_intercept
  }
  if (tol<0){
    upper_shrink=new_intercept
  }
  rm(prediction_data)
  rm(reweighing_data)
  
  print("AFTER LOOP")
  print(gc())
}
new_intercept=data.frame(new_intercept)
fwrite(new_intercept,paste0("/proj/sens2020559/COVID-19/MyData/Calibrations",modeltype,sensitivity,SCAD,".txt"))
print(paste0("8_intercept calibration finished",modeltype,sensitivity,SCAD))

fwrite(flowchart,paste0("/proj/sens2020559/COVID-19/Results/8_intercept_calibration_flowchart",sensitivity,new_model,".txt"))

#When running the Stata CRUSH_preprocessiong.do-file, the contents of this .txt-file will be opened and used to determine whether the file is 
#to be run for main or timeupdated (by creating a local)
if (modeltype=="") tostata2="main"
if (modeltype=="TUP") tostata2="tup"
fwrite(data.frame(tostata2),"/proj/sens2020559/COVID-19/MyData/Stata_local_model.txt")
rm(tostata2)