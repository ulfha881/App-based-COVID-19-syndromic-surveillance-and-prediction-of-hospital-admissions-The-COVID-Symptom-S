#The code starts with opening swedish and/or UK files containing information about which postal codes belong to which counties/regions (which are then merged to the main file by postal code).
#Then it opens the assessment file (current swedish, model building or UK), make sure that each user only has one
#report per day (in which the "max" of symptoms are choosen) and that each symptom is defined as binary 1/0-variables.
#It then opens the patient file (patient_data), makes sure that duplicate rows are dropped and that reported by another=FALSE. 
#It then stores some datasets in Stata code for creating descriptive tables (table1a, 1b and 1c)
#for the diabetes study (in which the assessment variables are one row per user, see "data_aggr"-object). 
#Subjects aged below 18, without reporting either male or female or without known county/region are dropped.
#It then merges the patient file with the assessment data (assess_data) and generates a file ("FullPredictionFile.txt") for making predictions.

#The UK data has two complications, since the assessment files are split up into chunks. 
#First, the seven last days of each files except the first are saved in a separate dataset and appended, so last observation carried forward (see files 8-10) can be performed
#Also, a separate file is created for the date of first assessment for each individual (English_first_assessment.R).
source("globalArgs.R")

library("xlsx")
library("data.table")
library("haven")
library("lubridate")
library("assertable")
library("readxl")
library("stringr")

#When running the Stata table1-file, the contents of this .txt-file will be opened and used to determine whether the file is 
#to be run for UK or SWE (by creating a local)
if (ukdata=="ukdata") tostata="ukdata"
if (ukdata!="ukdata") tostata="swedata"
fwrite(data.frame(tostata),"/proj/sens2020559/COVID-19/MyData/Stata_local.txt")
rm(tostata)

if (ukdata=="ukdata"){
  #Dataset with english regional postal codes
  english_regions=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/England_postal.dta"))
  english_regions[,five_digit_postcode:=as.character(five_digit_postcode)]
  fwrite(english_regions,"/proj/sens2020559/COVID-19/MyData/postal_check.txt") #REMOVE?
}

#Contains information about which five-digit-codes matches to which county (swedish postal codes.
data_postal=data.table(read_excel("/proj/sens2020559/COVID-19/OriginalData/postnummerservice_postcode_unique_lan_kommun_201130.xlsx"))
setnames(data_postal,'lanskod','Länskod')
names=c('Länskod','five_digit_postcode')
data_postal=data_postal[,..names]
data_postal[,five_digit_postcode:=as.numeric(five_digit_postcode)]
data_postal=unique(data_postal)
setkey(data_postal,'five_digit_postcode')

#ASSESSEMENT FILE
#This is the file with user symptoms assessments for each file. 
#for increased speed: keep necessary columns, convert time variable and other symptoms variable to numeric

selection=c('patient_id','fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
'chest_pain','hoarse_voice','loss_of_smell','headache','chills_or_shivers','eye_soreness',
'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
'typical_hayfever','sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath',
'health_status','updated_at','other_symptoms','altered_smell','unusual_joint_pains')

if (ukdata!="ukdata" & new_model=="") assess_data<-fread("/proj/sens2020559/COVID-19/OriginalData/Current_SWE/assessments.txt",sep=",",select=selection)
if (ukdata!="ukdata" & new_model=="new_model") assess_data<-fread("/proj/sens2020559/COVID-19/OriginalData/ModelBuilding/assessments.txt",sep=",",select=selection)
if (ukdata=="ukdata") assess_data<-fread(filereader,sep=",",select=selection)

#Loss of smell changed to "true" if altered smell is "true"
assess_data[altered_smell==TRUE,loss_of_smell:=TRUE]
assess_data[,altered_smell:=NULL]
assess_data[,unusual_joint_pains:=NULL] 

flowchart=cbind("Number of rows in assessment file",length(assess_data[,patient_id]))
pid=assess_data[,patient_id]
pid=unique(pid)
flowchart=rbind(flowchart,cbind("Number of patients in assessment file",length(pid)))

#change format of variables for increased speed
assess_data[,updated_at:=substr(updated_at,1,10)]
assess_data[,updated_at:=ymd(updated_at)]
assess_data[,other_symptoms:=substr(other_symptoms,1,4)]
assess_data[other_symptoms!="",other_symptoms:="1"]
assess_data[other_symptoms=="",other_symptoms:="0"]

#change definitions of fatigue and shortness of breath
assess_data[fatigue=="severe",fatigue:="TRUE"]
assess_data[fatigue=="mild" | fatigue=="no",fatigue:="FALSE"]
assess_data[,fatigue:=as.logical(fatigue)]
assess_data[shortness_of_breath=="severe" | shortness_of_breath=="significant",shortness_of_breath:="TRUE"]
assess_data[shortness_of_breath=="mild" | shortness_of_breath=="no",shortness_of_breath:="FALSE"]
assess_data[,shortness_of_breath:=as.logical(shortness_of_breath)]

#change symptoms to numeric
symptoms=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
           'chest_pain','hoarse_voice','loss_of_smell','headache','chills_or_shivers','eye_soreness',
           'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet','typical_hayfever',
           'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath','other_symptoms')
assess_data[,(symptoms):=lapply(.SD,as.numeric),.SDcols=symptoms]

#ensure symptoms=0 when health status=healthy
for (i in symptoms){
  assess_data[health_status=="healthy",(i):=0]
}
assess_data[,health_status:=NULL] #not needed anymore

#modifying assessment data to one row per user and day
pid_assess=assess_data[,patient_id]
pid_assess=unique(pid_assess)
assess_data[,(symptoms):=lapply(.SD,max,na.rm=TRUE),by=.(patient_id,updated_at),.SDcols=symptoms]
assess_data=unique(assess_data)

#Get rid of -Inf, which happens with max,na.rm=TRUE when all obs. are NA:s.
for (i in symptoms){
  assess_data[get(i)<0,(i):=0]
}
tokeep=c('patient_id','updated_at')
tokeep=union(tokeep,symptoms) #we want to keep symptoms+names

flowchart=rbind(flowchart,cbind("Number of rows in one-row-per-user-and-day assessment file",length(assess_data[,patient_id])))
flowchart=rbind(flowchart,cbind("Number of patients in one-row-per-user-and-day assessment file",length(unique(assess_data[,patient_id]))))

#stores symptom information required for the model. To some extent "redundant" since this
#information is also contained in the FullPredictionData.dta-file below,
#but that file contains variables which are not needed for the model building, and which slows down the code
if (new_model=="new_model") fwrite(assess_data,file="/proj/sens2020559/COVID-19/MyData/Assessment_for_model",col.names=T)
if (new_model=="") fwrite(assess_data,file="/proj/sens2020559/COVID-19/MyData/Assessment_for_model_validation",col.names=T)
#UK data is divided into chunks, and we use a 7-day LOCF. 
#Thus we need to append the last 7 days from the UK dataset previous in time. So this loop is required for all except the earliest UK dataset.
#It's reeally week 12_13_14 2020 but changed to have same format and number of characters as the remaining files.
if (ukdata=="ukdata"){
  if (filereader!="/proj/sens2020559/georgioray/Splits_week/0week_13_14_2020.csv"){
    data_append=fread("/proj/sens2020559/COVID-19/MyData/Assessment_to_append") #LOCF
    data_append=data_append[,updated_at:=ymd(updated_at)]
    assess_data=data.table(rbind(assess_data,data_append))
  }
  assess_data[,updated_max:=max(updated_at)]
  assess_data[,updated_min:=updated_max-7]
  data_append=assess_data[updated_at<=updated_max & updated_at>=updated_min,]
  data_append[,updated_max:=NULL]
  data_append[,updated_min:=NULL]
  fwrite(data_append,"/proj/sens2020559/COVID-19/MyData/Assessment_to_append")
}

#We want the first assessment for each user. For UK, this part is done mostly in a separate code ("FirstAssessment_UK.R" due to the division into chunks)
assess_data[,times_assess:=.N,by=.(patient_id)] #times assess is here "how many days have user been active"?
if (ukdata!="ukdata") assess_data[,first_assess:=min(updated_at),by=.(patient_id)]
if (ukdata!="ukdata") assess_data[,latest_assess:=max(updated_at),by=.(patient_id)]
if (ukdata=="ukdata"){ 
  first_assess_data=fread("/proj/sens2020559/COVID-19/MyData/UK_first_assess.txt")
  setkey(first_assess_data,'patient_id')
  setkey(assess_data,'patient_id')
  assess_data=assess_data[first_assess_data,nomatch=0]
  rm(first_assess_data)
}
assess_data[,Month:=month(updated_at),by=.(patient_id)]

#table1 from Stata do-file
#modifying assessment data to one row per user (for table1)
names2=c('first_assess','Month','times_assess','latest_assess')
names=union(symptoms,names2)
data_aggr=assess_data[,lapply(.SD,max,na.rm=TRUE),by=.(patient_id),.SDcols=names]
pid=assess_data[,.(patient_id)] #the problem with aggregating lapply is that we risk dropping users with missing.
pid=unique(pid)
data_aggr=merge(data_aggr,pid,by='patient_id',all=TRUE)
fwrite(data_aggr,file="/proj/sens2020559/COVID-19/MyData/Assessment_tmp.txt",col.names=T)
lopnr_merge=data.table(unique(data_aggr[,patient_id]))
data_aggr=NULL

#2) USER INFORMATION FILE
if (ukdata=="" & new_model=="") patient_data<-fread("/proj/sens2020559/COVID-19/OriginalData/Current_SWE/patients.txt",sep=",")
if (ukdata=="" & new_model=="new_model") patient_data<-fread("/proj/sens2020559/COVID-19/OriginalData/ModelBuilding/patients.txt",sep=",")
if (ukdata=="ukdata") patient_data<-fread("/proj/sens2020559/COVID-19/OriginalData/Current_UK/patients.txt",sep=",")

setnames(patient_data,"id","patient_id",skip_absent=TRUE) #skip_absent added 2022-01-31 for toy dataset to run.

if (ukdata=="ukdata"){
  patient_data[,se_postcode:=NULL]
  patient_data[,outward_postcode:=str_replace_all(outward_postcode,pattern=" ",repl="")]
}

if (ukdata=="ukdata") setnames(patient_data,"outward_postcode","se_postcode") 

flowchart=rbind(flowchart,cbind("Number of rows in patient file",length(patient_data[,patient_id])))

pid=patient_data[,patient_id]
pid=data.table(unique(pid))
fwrite(pid,"/proj/sens2020559/COVID-19/MyData/patient_id_all.txt")
if (ukdata!="ukdata") fwrite(pid,"/proj/sens2020559/COVID-19/MyData/patient_id_SWE.txt")

#Keep only necessary variables (which removes problem with duplicate rows)
varlist=c('patient_id','has_diabetes','gender','year_of_birth','bmi','smoker_status','has_kidney_disease','has_cancer',
          'takes_immunosuppressants','healthcare_professional','has_lung_disease','has_heart_disease',
          'takes_any_blood_pressure_medications','has_asthma','has_lung_disease_only',
          'a1c_measurement_percent','a1c_measurement_mmol','se_postcode',
          'diabetes_diagnosis_year','diabetes_oral_other_medication','diabetes_uses_cgm',
          'diabetes_type','reported_by_another','height_cm','weight_kg','diabetes_type_other','created_at','is_pregnant','pregnant_weeks')
varlist2=grep("diabetes_treatment",names(patient_data),value=TRUE)
varlist3=grep("diabetes_oral",names(patient_data),value=TRUE)
varlist=union(varlist,varlist2)
varlist=union(varlist,varlist3)
patient_data=patient_data[,..varlist]
patient_data[,diabetes_treatment_other_injection:=NULL] #unnecessary, and variable name too long for stata
patient_data=unique(patient_data)
stopifnot(!duplicated(patient_data[,patient_id]))

flowchart=rbind(flowchart,cbind("Number of unique ID:s in patient file",length(patient_data[,patient_id])))

patient_data=patient_data[reported_by_another=="FALSE",]
patient_data[,reported_by_another:=NULL]
patient_data[,created_at:=substr(created_at,1,10)]

if (ukdata!="ukdata") write_dta(patient_data,"/proj/sens2020559/COVID-19/MyData/table1_SWE.dta")
if (ukdata=="ukdata") write_dta(patient_data,"/proj/sens2020559/COVID-19/MyData/table1_UK.dta")

flowchart=rbind(flowchart,cbind("...after dropping reported by another",length(patient_data[,patient_id])))

#Merging with the postal code file created at the beginning of the document.
if (ukdata!="ukdata"){
  patient_data[,county:=""]
  patient_data[,four_digit_postcode:=as.numeric(substr(se_postcode,1,4))]
  patient_data[,three_digit_postcode:=as.numeric(substr(se_postcode,1,3))]
  patient_data[,two_digit_postcode:=as.numeric(substr(se_postcode,1,2))]
  patient_data[,five_digit_postcode:=as.numeric(se_postcode)]
  setkey(patient_data,'five_digit_postcode')
  patient_data=merge(patient_data,data_postal,by='five_digit_postcode',all.x=TRUE,all.y=FALSE)

  patient_data[Länskod=="01",county:="Stockholm"]
  patient_data[Länskod=="03",county:="Uppsala"]
  patient_data[Länskod=="04",county:="Södermanland"]
  patient_data[Länskod=="05",county:="Östergötland"]
  patient_data[Länskod=="06",county:="Jönköping"]
  patient_data[Länskod=="07",county:="Kronoberg"]
  patient_data[Länskod=="08",county:="Kalmar"]
  patient_data[Länskod=="09",county:="Gotland"]
  patient_data[Länskod=="10",county:="Blekinge"]
  patient_data[Länskod=="12",county:="Skåne"]
  patient_data[Länskod=="13",county:="Halland"]
  patient_data[Länskod=="14",county:="Västra Götaland"]
  patient_data[Länskod=="17",county:="Värmland"]
  patient_data[Länskod=="18",county:="Örebro"]
  patient_data[Länskod=="19",county:="Västmanland"]
  patient_data[Länskod=="20",county:="Dalarna"]
  patient_data[Länskod=="21",county:="Gävleborg"]
  patient_data[Länskod=="22",county:="Västernorrland"]
  patient_data[Länskod=="23",county:="Jämtland"]
  patient_data[Länskod=="24",county:="Västerbotten"]
  patient_data[Länskod=="25",county:="Norrbotten"]
}

if (ukdata=="ukdata"){
  patient_data[,county:=NULL]
  patient_data[,four_digit_postcode:=as.numeric(substr(se_postcode,1,4))]
  patient_data[,three_digit_postcode:=as.numeric(substr(se_postcode,1,3))]
  patient_data[,two_digit_postcode:=as.numeric(substr(se_postcode,1,2))]
  patient_data[,five_digit_postcode:=as.character(se_postcode)]
  setkey(patient_data,'five_digit_postcode')
  temp_UK=data.table(patient_data[,five_digit_postcode])
  fwrite(temp_UK,"/home/ulfha881/Desktop/COVID-19/MyData/postalcodes_UK_dataset.txt")
  rm(temp_UK)
  patient_data=merge(patient_data,english_regions,by='five_digit_postcode',all.x=FALSE,all.y=FALSE)
}

patient_data[,Länskod:=NULL]

#remove implausible values
patient_data[,created_at:=ymd(created_at)]
patient_data[,year:=year(created_at)]
patient_data[,created_at:=NULL]
patient_data[,age:=year-year_of_birth]
patient_data[age<18 | age>99,age:=NA]
patient_data[height_cm<130 | height_cm>210,height_cm:=NA]
if (ukdata!="ukdata"){ #weight and height totally weird for UK
  patient_data[weight_kg<35 | weight_kg>300,weight_kg:=NA]
  patient_data[,bmi:=NULL]
  patient_data[,bmi:=weight_kg/((height_cm/100)^2)]
  patient_data[bmi<15 | bmi>70,bmi:=NA]
}

columns=c('patient_id','bmi','height_cm','weight_kg','gender','age', 
          'healthcare_professional','county','two_digit_postcode','five_digit_postcode','four_digit_postcode','three_digit_postcode')
patient_data=patient_data[,..columns]
patient_data=patient_data[age>17 & age<100,]
patient_data=patient_data[gender==0 | gender==1,]
flowchart=rbind(flowchart,cbind("Number in data after age/gender exclusions",length(unique(patient_data[,patient_id]))))

setkey(patient_data,'patient_id')
patient_data=patient_data[lopnr_merge,nomatch=0]
setkey(patient_data,'five_digit_postcode')
patient_data=unique(patient_data)

patient_data[healthcare_professional=="yes_does_interact" | 
               healthcare_professional=="yes_does_not_interact" |
               healthcare_professional=="yes_does_not_treat" |
               healthcare_professional=="yes_does_treat"
             ,healthcare_professional:="1"]
patient_data[healthcare_professional=="" | healthcare_professional=="no",healthcare_professional:="0"]
patient_data[,healthcare_professional:=as.numeric(healthcare_professional)]

if (new_model=="new_model") write_dta(patient_data,"/proj/sens2020559/COVID-19/MyData/patient_data_for_model.dta")
if (new_model=="") write_dta(patient_data,"/proj/sens2020559/COVID-19/MyData/patient_data_for_model_validation.dta")

setkey(patient_data,"patient_id")
setkey(assess_data,"patient_id")
flowchart=rbind(flowchart,cbind("Number of rows in the patient/prediction file after merging with assessment data (I) (sanity check)",length(patient_data[,patient_id])))
patient_data=patient_data[assess_data,nomatch=0]
flowchart=rbind(flowchart,cbind("Number of rows in the patient/prediction file after merging with assessment data (II)",length(patient_data[,patient_id])))
patient_data=unique(patient_data)
flowchart=rbind(flowchart,cbind("Assert no duplicates",length(patient_data[,patient_id])))

rm(assess_data)
patient_data[,county:=as.character(county)]

#Removes participants after they've reported loss of smell for more than 30 days in total.
#Also removes the first seven days after first assessment.
#cumsum can't handle NA, therefore temporary variable with NA=0
patient_data=patient_data[loss_of_smell<0,loss_of_smell:=0]
patient_data=patient_data[,loss_of_tmp:=loss_of_smell]
patient_data=patient_data[is.na(loss_of_smell),loss_of_tmp:=0]
patient_data=patient_data[is.na(loss_of_smell),loss_of_tmp:=0]
patient_data=patient_data[,days_reporting_LOS:=cumsum(loss_of_tmp),by=patient_id]
patient_data=patient_data[,loss_of_tmp:=NULL]
patient_data[,updated_at:=ymd(updated_at)]
patient_data[,first_assess:=ymd(first_assess)]
patient_data[,time_since_first_assess:=updated_at-first_assess]
patient_data=data.table(patient_data)

#strata for later population re-weighting
patient_data[age>49 & gender==0,group:=1] #kvinnor
patient_data[age<50 & gender==0,group:=2]
patient_data[age>49 & gender==1,group:=3] #män
patient_data[age<50 & gender==1,group:=4]

patient_data[,number_of_assess:=.N,by=updated_at]
patient_data[,number_of_assess_strata:=.N,by=.(updated_at,group)]

#for generating figure 2. Flag==1 means that they are used in prediction and/or model building.
if (ukdata!="ukdata" & new_model!="new_model"){
  pid_model=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/PID_model.dta")) #PID_model.dta is generated in 10_model_building_strata_nationwide
  pid_model[,extra_flag:=1]
  patient_data[,flag:=0]
  patient_data[time_since_first_assess>7,flag:=1]
  patient_data[county=="",flag:=0]
  patient_data=merge(patient_data,pid_model,by="patient_id",all.x=TRUE,all.y=TRUE)
  #patient_data[extra_flag==1,flag:=1]
  patient_data[extra_flag!=1,flag:=1] #modified 20211112
  patient_data[,extra_flag:=NULL]
  patient_data[,flag:=max(flag),by=.(patient_id)]
  patient_data[,number_of_assess_main:=.N,by=.(updated_at,flag)]
  patient_data[,number_of_assess_strata_main:=.N,by=.(updated_at,group,flag)]
  graph_data=patient_data[,.(updated_at,number_of_assess,number_of_assess_strata,group,number_of_assess_main,number_of_assess_strata_main,flag)]
  graph_data=unique(graph_data)
  fwrite(graph_data,"/proj/sens2020559/COVID-19/MyData/GraphData.txt")
  graph_data=NULL
  patient_data[,number_of_assess:=NULL]
  patient_data[,number_of_assess_strata:=NULL]
  patient_data[,number_of_assess_main:=NULL]
  patient_data[,number_of_assess_strata_main:=NULL]
}

columns=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
          'chest_pain','hoarse_voice','loss_of_smell','headache','chills_or_shivers','eye_soreness',
          'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
          'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath',
          'gender','age','updated_at','patient_id','group','county','two_digit_postcode',
          'three_digit_postcode','four_digit_postcode','five_digit_postcode','healthcare_professional',
          'time_since_first_assess','days_reporting_LOS')
patient_data=patient_data[,..columns]

flowchart=rbind(flowchart,cbind("Number in data",length(unique(patient_data[,patient_id]))))
patient_data[,time_since_first_assess:=as.numeric(time_since_first_assess)]

#for looking at whether early days were more symptomatic for users.
early_data=patient_data[time_since_first_assess<8,]
fwrite(early_data,paste0("/proj/sens2020559/COVID-19/MyData/EarlyPredictionData",ukdata,".txt"))
patient_data=patient_data[time_since_first_assess>7,]

flowchart=rbind(flowchart,cbind("Number in data after 7 days",length(unique(patient_data[,patient_id]))))

patient_data[,time_since_first_assess:=NULL]
patient_data=data.table(patient_data)
patient_data=patient_data[days_reporting_LOS<31,] #OBS!!! COMMENTED AWAY VERY TEMPORARILY 20210104

flowchart=rbind(flowchart,cbind("Number in data after LOS",length(unique(patient_data[,patient_id]))))
patient_data=patient_data[,days_reporting_LOS:=NULL]

if (ukdata!="ukdata") patient_data=patient_data[updated_at>ymd("20200503"),]

patient_data=patient_data[county!="",]
early_data=early_data[county!="",]

#changing to match hospitalization regions (7 instead of 9)
if (ukdata=="ukdata"){ 
  setnames(patient_data,"county","region")
  patient_data[region=="North East" | region=="Yorkshire and The Humber",region:="North East and Yorkshire"]
  patient_data[region=="West Midlands" | region=="East Midlands",region:="Midlands"]
}
#PID_predict.dta is used for the descriptive tables in "Table1_20201029.do"
pid_predict=patient_data[,.(patient_id)]
pid_predict=unique(pid_predict)
write_dta(pid_predict,"/proj/sens2020559/COVID-19/MyData/PID_predict.dta")
fwrite(patient_data,"/proj/sens2020559/COVID-19/MyData/FullPredictionData.txt")

flowchart=rbind(flowchart,cbind("Number in data after dropping missing county",length(unique(patient_data[,patient_id]))))
#patient_data=unique(patient_data)

symptoms=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
   'chest_pain','hoarse_voice','loss_of_smell','headache','chills_or_shivers','eye_soreness',
   'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
   'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath')

if (ukdata!="ukdata" & new_model=="new_model"){
  #generating a specific dataset for 8_intercept_calibration since there are memory problems
  #due to R having problems cleaning up memory.
  columns=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
            'chest_pain','hoarse_voice','loss_of_smell','headache','eye_soreness',
            'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
            'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath',
            'gender','age','updated_at','patient_id','group','healthcare_professional','county')
  #columns=c(columns,type)
  patient_data[,updated_at:=ymd(updated_at)]
  patient_data2=patient_data[updated_at<ymd("20200620"),] 
  #patient_data2=patient_data[updated_at<ymd("20200610") & updated_at>ymd("20200515"),] 
  ##patient_data2=patient_data2[,..columns]
  fwrite(patient_data2,"/proj/sens2020559/COVID-19/MyData/PredictionData_Calibration.txt")
}

#the average number of symptoms per patient and day for <=7 days dataset and >7 days dataset.
early_data[,any_symptom_positive:=apply(.SD,1,max,na.rm=TRUE),by=1:nrow(early_data),.SDcols=symptoms]
patient_data[,any_symptom_positive:=apply(.SD,1,max,na.rm=TRUE),by=1:nrow(patient_data),.SDcols=symptoms]
flowchart=rbind(flowchart,cbind("Average no of symptoms per day and patient, <=7 days",mean(early_data[,any_symptom_positive])))
flowchart=rbind(flowchart,cbind("Average no of symptoms per day and patient, >7 days",mean(patient_data[,any_symptom_positive])))


fwrite(flowchart,paste0("/proj/sens2020559/COVID-19/Results/2_preprocessing_flowchart",ukdata,new_model,".txt"))

rm(patient_data)
rm(flowchart)
rm(early_data)
rm(data_postal)
rm(data_aggr)
rm(pid_predict)

print("2 preprocessing abbrev finished")