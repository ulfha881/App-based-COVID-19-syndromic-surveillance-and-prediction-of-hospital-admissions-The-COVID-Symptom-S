library(data.table)

UK_files2=list.files(path="/proj/sens2020559/georgioray/Splits_week/")

for (UK_fileread in UK_files2){
  assess_data<-fread(paste0("/proj/sens2020559/georgioray/Splits_week/",UK_fileread),sep=",",
                    select=c('patient_id','updated_at'))
  assess_data[,first_assess:=min(updated_at),by=.(patient_id)]
  assess_data[,latest_assess:=max(updated_at),by=.(patient_id)]
  assess_data[,updated_at:=NULL]
  assess_data=unique(assess_data)
  
  if (UK_fileread=="0week_13_14_2020.csv"){
    fwrite(assess_data,"/proj/sens2020559/COVID-19/MyData/tempfile")
    assess_data=NULL
  }
  if (UK_fileread!="0week_13_14_2020.csv"){
    append_data=fread("/proj/sens2020559/COVID-19/MyData/tempfile")
    assess_data=data.table(rbind(assess_data,append_data))
    assess_data[,first_assess:=min(first_assess),by=.(patient_id)]
    assess_data[,latest_assess:=max(latest_assess),by=.(patient_id)]
    assess_data=unique(assess_data)
    fwrite(assess_data,"/proj/sens2020559/COVID-19/MyData/tempfile")
  }
}

fwrite(assess_data,"/proj/sens2020559/COVID-19/MyData/UK_first_assess.txt")
print(warnings())
print("Code finished")