#This function is used for building the model in files 8-10.

model_building<-function(){
  library("data.table")
  library("haven")
  library("lubridate")
  library("glmnet")
  library("pROC")
  library("ggplot2")
  library("foreach")
  library("zoo")
  library("scales")
  library("epitools")
  library("splines")
  library("ncvreg") 
  
  model_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/ModelData.dta")) #Frim 4_merge_covid_assessment_preprocessing, only generated when new_model=="new_model"
  
  if (new_model=="new_model" & dataset=="train_data") write_dta(model_data,"/proj/sens2020559/COVID-19/MyData/ModelData_Current.dta")
  model_data=data.table(read_dta("/proj/sens2020559/COVID-19/MyData/ModelData_Current.dta"))
  
  #if covid tests sensitivity analysis is specified.
  if (sensitivity=="sensitivity"){
    sens_data=read_dta("/proj/sens2020559/COVID-19/MyData/Patients_for_sensitivity_analys.dta")
    model_data=merge(model_data,sens_data,by='patient_id')
    rm(sens_data)
  }
  
  #making sure only patients without withdrawn consent as of 20211110 are used for the model.
  pid=fread("/proj/sens2020559/COVID-19/MyData/patient_id_SWE.txt") #changed from patient_id_all 20211102
  setnames(pid,'V1','patient_id')
  model_data=merge(model_data,pid,by='patient_id')
  write_dta(model_data,"/proj/sens2020559/COVID-19/MyData/ModelData_Current_Update.dta")
  
  model_data=model_data[SymptomDate<ymd("20210101"),]
  
  if (new_model=="new_model" & dataset=="train_data"){
    pid_model=model_data[,.(patient_id)]
    write_dta(pid_model,"/proj/sens2020559/COVID-19/MyData/PID_model.dta")
  }
  
  #create cubic splines if user specifies modeltype=="TUP". Knot placements are stored in objects 'knots' and 'bknots'
  #to be identical in prediction data and model data.
  if (modeltype=="TUP"){
    m=ns(model_data[,SymptomDate],df=6)
    model_data[,time_spl1:=..m[,1]]
    model_data[,time_spl2:=..m[,2]]
    model_data[,time_spl3:=..m[,3]]
    model_data[,time_spl4:=..m[,4]]
    model_data[,time_spl5:=..m[,5]]
    model_data[,time_spl6:=..m[,6]]
    knots=attr(m,"knots")
    bknots=attr(m,"Boundary.knots")
  }
  
  #columns=columns required when building the model.
  columns=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
            'chest_pain','hoarse_voice','loss_of_smell','headache','eye_soreness',
            'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
            'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath',
            'covid','gender','age')
  
  #The 'timevar' object is added to lists of columns/variables here and later in the code if modeltype=="TUP" is specified.
  if (modeltype=="TUP"){ 
    timevar=c('time_spl1','time_spl2','time_spl3','time_spl4','time_spl5','time_spl6')
    columns=c(columns,timevar)
  }

  model_data=model_data[,..columns] #all symptoms + gender/age as potential predictors + covid as outcome.
  
  #variables=variables which are hypothesized to have interactions with loss of smell in the model.
  variables=c('fever','persistent_cough','diarrhoea','delirium','skipped_meals','abdominal_pain',
              'chest_pain','hoarse_voice','headache','eye_soreness',
              'nausea','dizzy_light_headed','red_welts_on_face_or_lips','blisters_on_feet',
              'sore_throat','unusual_muscle_pains','fatigue','shortness_of_breath','gender','age')
  if (modeltype=="TUP") variables=c(variables,timevar)

  #create interaction terms between loss of smell and other variables.
  for (i in variables){
    model_data[,paste0("loss_",i):=loss_of_smell*get(i)]
  }
  
  model_data=na.omit(model_data)
  
  #outcome must be stored in separate vector for LASSO/SCAD
  covid=as.factor(model_data[,covid])
  model_data[,covid:=NULL]
  model_data=as.matrix(model_data)
  
  #runs LASSO. 10-fold-CV for choosing lambda.
  if (SCAD=="SCAD"){
    model=cv.ncvreg(X=model_data,y=covid,family='binomial',nfolds=10,penalty="SCAD")
    model2=ncvreg(X=model_data,y=covid,family='binomial',lambda=model$lambda.min,penalty="SCAD")
  }
  if (SCAD!="SCAD"){
    model=cv.glmnet(x=model_data,y=covid,family='binomial',nfolds=10)
    model2=glmnet(x=model_data,y=covid,family='binomial',lambda=model$lambda.min)
    variable_list=model2$beta@Dimnames[[1]]
    write.table(variable_list,"/proj/sens2020559/COVID-19/MyData/Coefficients_Intercept.txt") # not used in any other file
  }

  #if (SCAD=="SCAD") model2$a0=model2$beta[1]
  
  if (SCAD!="SCAD"){
    #stores coefficient for the model
    coefs=coef(model2)
    my_coefs=coefs[which(coefs!=0)]
    my_coef_names=coefs@Dimnames[[1]][which(coefs!=0)]
    tmp2=cbind(my_coefs,my_coef_names)
    write.table(tmp2,paste0("/proj/sens2020559/COVID-19/MyData/Coefficients",modeltype,sensitivity,".txt"))
  }
  
  #we need these five objects in the remainder of the code - we therefore make them exist outside the function.
  assign("model2",model2,envir=.GlobalEnv)
  if (modeltype=="TUP") assign("knots",knots,envir=.GlobalEnv)
  if (modeltype=="TUP") assign("bknots",bknots,envir=.GlobalEnv)
  assign("variables",variables,envir=.GlobalEnv)
  if (modeltype=="TUP") assign("timevar",timevar,envir=.GlobalEnv)
}
